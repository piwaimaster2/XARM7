#!/usr/bin/env python3
"""
Hand-eye calibration demo (eye-in-hand).

Collect samples by moving the Charuco board in front of the camera while providing
gripper poses. For a real robot, replace get_gripper_pose() with your robot API.

Requires: opencv-contrib-python (for cv2.aruco), scipy
Generate board: python -c "from hand_eye_calibration import generate_charuco_board_image; generate_charuco_board_image('charuco_board.png')"
Or use https://chev.me/arucogen/ - Dict 5x5, 9x14, Square 20mm, Marker 16mm
"""

import argparse
import os

import cv2
import numpy as np

from hand_eye_calibration import (
    HandCameraCalibrator,
    ThirdPersonCameraCalibrator,
    calibration_traj,
    save_calibration_info,
)
from realsense_wrapper import RealsenseD435i


def get_gripper_pose_demo(step: int, total_steps: int, hand_camera: bool) -> np.ndarray:
    """
    Demo: synthesize gripper pose from calibration trajectory.
    Replace with: return np.array(robot.get_cartesian_position())  # [x,y,z,rx,ry,rz]
    """
    t = 2 * np.pi * step / max(total_steps - 1, 1)
    return calibration_traj(t, hand_camera=hand_camera)


def run_calibration(
    mode: str = "hand",
    output_path: str = "calibration/calibration_info.json",
    num_samples: int = 30,
):
    """Collect samples and run hand-eye calibration."""
    cam_id = "realsense_d435i"
    hand_camera = mode == "hand"

    print(f"Hand-eye calibration ({mode} mode)")
    print("Move the Charuco board through different poses. Press SPACE to capture, Q to finish.")
    print("Target: at least 15–20 good samples with board clearly visible.\n")

    with RealsenseD435i() as cam:
        intr = cam.get_intrinsics()
        CalibratorClass = HandCameraCalibrator if hand_camera else ThirdPersonCameraCalibrator
        calibrator = CalibratorClass(intr)

        sample_count = 0
        while sample_count < num_samples:
            frame = cam.get_frame()
            if frame is None:
                continue

            rgb = frame.rgb
            augmented = calibrator.augment_image(cam_id, rgb, visualize=False, visual_type=["markers", "axes"])
            cv2.putText(
                augmented,
                f"Samples: {sample_count}/{num_samples}  SPACE=capture Q=quit",
                (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 255, 0),
                2,
            )
            cv2.imshow("Calibration - move board, SPACE to capture", augmented)

            key = cv2.waitKey(30) & 0xFF
            if key == ord("q"):
                break
            if key == ord(" "):
                pose = get_gripper_pose_demo(sample_count, num_samples, hand_camera)
                if calibrator.add_sample(cam_id, rgb, pose):
                    sample_count += 1
                    print(f"  Captured sample {sample_count}")

        cv2.destroyAllWindows()

    if sample_count < 10:
        print("Need at least 10 samples. Calibration aborted.")
        return

    print("Running calibration...")
    result = calibrator.calibrate(cam_id)
    if result is None:
        print("Calibration failed (not enough inliers or reprojection error too high).")
        return

    save_calibration_info(output_path, cam_id, result.tolist())
    print(f"Calibration saved to {output_path}")
    print(f"  Camera pose [x,y,z,rx,ry,rz]: {result}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode",
        choices=["hand", "thirdperson"],
        default="hand",
        help="hand=eye-in-hand (camera on gripper), thirdperson=eye-to-hand",
    )
    parser.add_argument("--output", default="calibration/calibration_info.json")
    parser.add_argument("--samples", type=int, default=30)
    parser.add_argument("--generate-board", action="store_true", help="Generate Charuco board image and exit")
    args = parser.parse_args()

    if args.generate_board:
        from hand_eye_calibration import generate_charuco_board_image
        generate_charuco_board_image("charuco_board.png")
        return

    run_calibration(mode=args.mode, output_path=args.output, num_samples=args.samples)


if __name__ == "__main__":
    main()
