# App uninstall verification

![uninstall](https://user-images.githubusercontent.com/14967831/107590234-7e2f8800-6bbc-11eb-9803-5cc97fa48c37.jpg)

1. Put on your Oculus Quest
2. Press the Apps button in the Main Menu
3. Check if the app "RAIL Oculus Teleoperation" is not visible on the list.
