---
license: apache-2.0
task_categories:
- robotics
tags:
- LeRobot
configs:
- config_name: default
  data_files: data/*/*.parquet
---

This dataset was created using [LeRobot](https://github.com/huggingface/lerobot).

## Dataset Description



- **Homepage:** [More Information Needed]
- **Paper:** [More Information Needed]
- **License:** apache-2.0

## Dataset Structure

[meta/info.json](meta/info.json):
```json
{
    "codebase_version": "v3.0",
    "robot_type": "unknown",
    "total_episodes": 206,
    "total_frames": 25650,
    "total_tasks": 1,
    "chunks_size": 1000,
    "fps": 10,
    "splits": {
        "train": "0:206"
    },
    "data_path": "data/chunk-{chunk_index:03d}/file-{file_index:03d}.parquet",
    "video_path": "videos/{video_key}/chunk-{chunk_index:03d}/file-{file_index:03d}.mp4",
    "features": {
        "observation.image": {
            "dtype": "video",
            "shape": [
                96,
                96,
                3
            ],
            "names": [
                "height",
                "width",
                "channel"
            ],
            "video_info": {
                "video.fps": 10.0,
                "video.codec": "av1",
                "video.pix_fmt": "yuv420p",
                "video.is_depth_map": false,
                "has_audio": false
            }
        },
        "observation.state": {
            "dtype": "float32",
            "shape": [
                2
            ],
            "names": {
                "motors": [
                    "motor_0",
                    "motor_1"
                ]
            },
            "fps": 10.0
        },
        "action": {
            "dtype": "float32",
            "shape": [
                2
            ],
            "names": {
                "motors": [
                    "motor_0",
                    "motor_1"
                ]
            },
            "fps": 10.0
        },
        "episode_index": {
            "dtype": "int64",
            "shape": [
                1
            ],
            "names": null,
            "fps": 10.0
        },
        "frame_index": {
            "dtype": "int64",
            "shape": [
                1
            ],
            "names": null,
            "fps": 10.0
        },
        "timestamp": {
            "dtype": "float32",
            "shape": [
                1
            ],
            "names": null,
            "fps": 10.0
        },
        "next.reward": {
            "dtype": "float32",
            "shape": [
                1
            ],
            "names": null,
            "fps": 10.0
        },
        "next.done": {
            "dtype": "bool",
            "shape": [
                1
            ],
            "names": null,
            "fps": 10.0
        },
        "next.success": {
            "dtype": "bool",
            "shape": [
                1
            ],
            "names": null,
            "fps": 10.0
        },
        "index": {
            "dtype": "int64",
            "shape": [
                1
            ],
            "names": null,
            "fps": 10.0
        },
        "task_index": {
            "dtype": "int64",
            "shape": [
                1
            ],
            "names": null,
            "fps": 10.0
        }
    },
    "data_files_size_in_mb": 100,
    "video_files_size_in_mb": 500
}
```


## Citation

**BibTeX:**

```bibtex
[More Information Needed]
```