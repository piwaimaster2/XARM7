"""
Robot adapters for S-O-A recording: read current state from xArm7 or DROID-SLAM trajectory.

State format: [x, y, z, rx, ry, rz] in meters and radians (Euler xyz).
"""

from __future__ import annotations

from typing import Callable, List, Optional, Union

import numpy as np

RobotGetState = Callable[[], np.ndarray]


# -----------------------------------------------------------------------------
# xArm7 API
# -----------------------------------------------------------------------------

def make_xarm7_get_state(
    arm: "XArmAPI",
    use_joints: bool = False,
    mm_to_m: bool = True,
    radians: bool = True,
) -> RobotGetState:
    """
    Create get_state() that reads current state from xArm7.

    Args:
        arm: XArmAPI instance (from xarm.wrapper import XArmAPI).
        use_joints: If True, return joint angles [7]. If False, return EE pose [x,y,z,rx,ry,rz].
        mm_to_m: If True, convert x,y,z from mm to meters.
        radians: Ensure angles are in radians (xArm can return degrees).

    Returns:
        Callable that returns np.ndarray of shape (6,) or (7,).
    """
    def get_state() -> np.ndarray:
        if use_joints:
            angles = arm.angles  # [7] in deg or rad depending on is_radian
            arr = np.array(angles, dtype=np.float64)
            if not arm.default_is_radian:
                arr = np.deg2rad(arr)
            if arr.size < 6:
                return np.resize(arr, 6)
            return arr[:6] if arr.size == 7 else arr  # ee_pose expects 6
        else:
            code, pos = arm.get_position(is_radian=radians)
            if code != 0:
                raise RuntimeError(f"xArm get_position failed: code={code}")
            arr = np.array(pos, dtype=np.float64)  # [x,y,z,roll,pitch,yaw]
            if mm_to_m:
                arr[:3] *= 0.001  # mm -> m
            if arr.size < 6:
                return np.resize(arr, 6)
            return arr[:6]

    return get_state


def get_joint_angles_from_xarm7(arm: "XArmAPI") -> RobotGetState:
    """
    Create get_joint_angles() that reads 7 joint angles (radians) from xArm7.
    Use alongside get_state (ee_pose) to record both pose and joint angles.
    """
    def get_joint_angles() -> np.ndarray:
        angles = arm.angles  # [7] in deg or rad depending on is_radian
        arr = np.array(angles, dtype=np.float64)
        if not arm.default_is_radian:
            arr = np.deg2rad(arr)
        return arr[:7] if arr.size >= 7 else np.resize(arr, 7)

    return get_joint_angles


RobotGetGripper = Callable[[], np.ndarray]


def get_gripper_position_from_xarm7(arm: "XArmAPI") -> RobotGetGripper:
    """
    Create get_gripper_position() that reads current gripper position from xArm7.

    Returns a callable that returns np.ndarray of shape (1,) with gripper position
    (typically 0 = closed, larger values = open; units depend on xArm model/SDK).
    """
    def get_gripper_position() -> np.ndarray:
        # XArmAPI.get_gripper_position() returns (code, position) or similar
        ret = arm.get_gripper_position()
        if isinstance(ret, (list, tuple)) and len(ret) >= 2:
            code, pos = ret[0], ret[1]
            if code != 0:
                return np.array([0.0], dtype=np.float64)  # fallback on error
            return np.array([float(pos)], dtype=np.float64)
        if isinstance(ret, (int, float)):
            return np.array([float(ret)], dtype=np.float64)
        return np.array([0.0], dtype=np.float64)

    return get_gripper_position


def connect_xarm7(
    port: str = "192.168.1.185",
    is_radian: bool = True,
) -> "XArmAPI":
    """
    Connect to xArm7 and return XArmAPI instance.
    Caller must keep arm connected; use arm.disconnect() when done.

    Requires: pip install xArm-Python-SDK
    """
    try:
        from xarm.wrapper import XArmAPI
    except ImportError as e:
        raise ImportError("xArm-Python-SDK required. pip install xArm-Python-SDK") from e
    arm = XArmAPI(port, is_radian=is_radian)
    arm.connect()
    return arm


# -----------------------------------------------------------------------------
# DROID-SLAM trajectory
# -----------------------------------------------------------------------------

def make_droid_get_state_factory(
    trajectory: Union[np.ndarray, List[np.ndarray]],
) -> "GetStateFactory":
    """
    Create get_state_factory(step) from a precomputed DROID-SLAM trajectory.

    DROID-SLAM outputs camera trajectory (poses in world frame). Use when:
      - DROID was run offline on a recorded image sequence
      - You have trajectory poses aligned to frame indices

    Args:
        trajectory: Array of shape (T, 6) or (T, 7) (quat) - camera poses per frame.

    Returns:
        Factory: (step) -> get_state callable. Use in record_soa(get_state_factory=...).
    """
    traj = np.asarray(trajectory)
    if traj.ndim == 1:
        traj = traj.reshape(1, -1)
    if traj.shape[1] == 7:
        traj = _quat_to_euler_xyz_batch(traj)
    elif traj.shape[1] > 6:
        traj = traj[:, :6]

    def factory(step: int) -> RobotGetState:
        i = min(step, traj.shape[0] - 1)
        return lambda: np.array(traj[i], dtype=np.float64)

    return factory


GetStateFactory = Callable[[int], RobotGetState]


def _quat_to_euler_xyz_batch(poses: np.ndarray) -> np.ndarray:
    """Convert [x,y,z,qw,qx,qy,qz] to [x,y,z,rx,ry,rz] Euler xyz."""
    from scipy.spatial.transform import Rotation as R
    xyz = poses[:, :3]
    quats = poses[:, 3:7]  # qw,qx,qy,qz for scipy
    euler = R.from_quat(quats).as_euler("xyz")
    return np.hstack([xyz, euler])


# -----------------------------------------------------------------------------
# Convenience
# -----------------------------------------------------------------------------

def get_state_from_xarm7(
    port: str = "192.168.1.185",
    use_joints: bool = False,
) -> tuple["XArmAPI", RobotGetState]:
    """
    Connect to xArm7 and return (arm, get_state).
    Caller must keep arm connected; call arm.disconnect() when done.
    """
    arm = connect_xarm7(port=port)
    return arm, make_xarm7_get_state(arm, use_joints=use_joints)


def get_gripper_from_xarm7(arm: "XArmAPI") -> RobotGetGripper:
    """Convenience: get gripper position callable for an already-connected xArm7."""
    return get_gripper_position_from_xarm7(arm)
