# RealSense D435i Wrapper — Full Usage Guide

This guide explains how to set up and use the entire repository: capture, recording, playback, and hand-eye calibration.

---

## 1. Repository layout

```
RealSense/
├── realsense_wrapper.py   # Main camera class, HDF5 reader
├── hand_eye_calibration.py # Hand-eye calibration (Charuco + OpenCV)
├── __init__.py
├── requirements.txt
├── README.md
├── USAGE.md               # This file
├── demo_capture.py        # Live RGB-D view
├── demo_record.py         # Record/replay HDF5
└── demo_calibration.py    # Hand-eye calibration demo
```

---

## 2. Prerequisites

- **Hardware**: Intel RealSense D435i (or D435; IMU is D435i-only).
- **OS**: Linux (Ubuntu recommended) or Windows with librealsense2 support.
- **Python**: 3.8+.

---

## 3. Installation

### Step 1: Install Intel librealsense2 (system)

**Ubuntu / Debian:**

```bash
# Add Intel repo and install
sudo apt-get update
sudo apt-get install -y librealsense2-dev librealsense2-utils

# Optional: udev rules so non-root can access the camera
sudo cp /etc/librealsense2/config/99-realsense-libusb.rules /etc/udev/rules.d/
sudo udevadm control --reload-rules && sudo udevadm trigger
```

**Verify:** Plug in the camera and run:

```bash
rs-enumerate-devices
```

You should see your D435i listed.

**Other platforms:** See [Intel RealSense installation](https://github.com/IntelRealSense/librealsense#installation).

### Step 2: Python environment

```bash
cd /path/to/RealSense
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

**Requirements:**

- `pyrealsense2` — RealSense Python bindings  
- `numpy`, `h5py` — arrays and HDF5 recording  
- `opencv-contrib-python` — demos and hand-eye (ArUco)  
- `scipy` — hand-eye calibration math  

### Step 3: Check that the camera works

```bash
python demo_capture.py
```

You should see a window with RGB and depth. Press **q** to quit. If this works, the rest of the repo can be used as below.

---

## 4. Use cases (in order)

### 4.1 Live RGB-D capture (no recording)

**When:** You want to process frames in real time (SLAM, control, visualization).

**Run demo:**

```bash
python demo_capture.py
```

**In your code:**

```python
from realsense_wrapper import RealsenseD435i

with RealsenseD435i() as cam:
    for t, rgb, depth, intrinsics, ts in cam.stream():
        # rgb: (H,W,3) BGR, depth: (H,W) uint16, intrinsics: Intrinsics
        do_something(rgb, depth, intrinsics)
```

Single frame:

```python
with RealsenseD435i() as cam:
    frame = cam.get_frame()
    rgb, depth = frame.rgb, frame.depth
    intrinsics = frame.intrinsics
```

---

### 4.2 DROID-SLAM–style image stream

**When:** You feed an image stream (and intrinsics) into DROID-SLAM or similar.

**1. Save a calibration file (once):**

```python
from realsense_wrapper import RealsenseD435i

with RealsenseD435i() as cam:
    cam.save_calibration("calib/realsense.txt")
```

**2. Stream images (and optionally use the same calib for offline runs):**

```python
with RealsenseD435i() as cam:
    for t, image, intrinsics in cam.image_stream(stride=3, as_tensor=True):
        # image: torch (3,H,W), intrinsics: torch [fx,fy,cx,cy]
        droid.track(t, image, intrinsics=intrinsics)
```

---

### 4.3 HDF5 recording and playback (like DROID SVO)

**When:** You want to record trajectories for later use (training, debugging, replay).

**Record:**

```bash
# Record ~10 s (300 frames at 30 fps) into recordings/demo.h5
python demo_record.py --record --path recordings/demo.h5 --frames 300
```

Or in code:

```python
from realsense_wrapper import RealsenseD435i

with RealsenseD435i() as cam:
    cam.start_recording("recordings/trajectory.h5")
    for _ in range(300):
        cam.get_frame()  # each frame is written to HDF5
    cam.stop_recording()
```

**Playback:**

```bash
python demo_record.py --replay --path recordings/demo.h5
```

Or in code:

```python
from realsense_wrapper import HDF5RecordingReader

with HDF5RecordingReader("recordings/trajectory.h5") as reader:
    n = reader.get_frame_count()
    for t, rgb, depth, ts in reader.stream():
        process_frame(rgb, depth)
```

**HDF5 contents:** `observations/image`, `observations/depth`, `observations/timestamp`, `metadata/intrinsics`, etc.

---

### 4.4 Hand-eye calibration

**When:** Camera is mounted on the robot (eye-in-hand) or fixed in the scene (eye-to-hand), and you need the camera pose in robot frame for control or mapping.

#### A. Generate a Charuco board (one-time)

```bash
python demo_calibration.py --generate-board
```

This creates `charuco_board.png`. Print it at **actual size** (squares 20 mm). Alternatively use [chev.me/arucogen](https://chev.me/arucogen/) with: Dict **5x5 (100)**, **9×14**, square **20 mm**, marker **16 mm**.

#### B. Run the calibration demo (no robot)

Demo uses **synthetic** gripper poses to show the pipeline:

```bash
python demo_calibration.py --mode hand --output calibration/calibration_info.json --samples 30
```

- Move the printed board in front of the camera.
- When the board is detected (markers + axes drawn), press **SPACE** to capture a sample.
- Capture at least 15–20 samples from different distances/angles, then press **Q**.
- Result is written to `calibration/calibration_info.json`.

#### C. Use with a real robot (eye-in-hand)

1. Mount the camera on the wrist; fix the Charuco board in the scene (or have someone hold it).
2. Move the robot so the camera sees the board from many poses.
3. For each pose, capture (image, gripper_pose). Gripper pose must be in **robot base frame**, **Euler XYZ** (radians): `[x, y, z, rx, ry, rz]`.

```python
from realsense_wrapper import RealsenseD435i
from hand_eye_calibration import HandCameraCalibrator, save_calibration_info

with RealsenseD435i() as cam:
    intr = cam.get_intrinsics()
    calibrator = HandCameraCalibrator(intr)

    # In your control loop: when board is visible and robot is steady
    rgb = cam.get_frame().rgb
    gripper_pose = robot.get_cartesian_pose()  # [x,y,z,rx,ry,rz] in base, euler xyz
    calibrator.add_sample("realsense", rgb, gripper_pose)

    # After 15+ samples
    result = calibrator.calibrate("realsense")  # camera pose in gripper frame
    if result is not None:
        save_calibration_info("calibration/calibration_info.json", "realsense", result)
```

#### D. Eye-to-hand (fixed camera)

Use `ThirdPersonCameraCalibrator` instead of `HandCameraCalibrator`. The robot holds (or moves relative to) the board; you still provide gripper pose in base frame. Output is **camera pose in robot base frame**.

#### E. Using the saved calibration

```python
from hand_eye_calibration import load_calibration_info

calib = load_calibration_info("calibration/calibration_info.json")
camera_pose = calib["realsense_d435i"]  # or your cam_id
# camera_pose: [x,y,z,rx,ry,rz] — use for T_gripper_camera or T_base_camera
```

Use this transform to convert points/poses from camera to robot frame (e.g. for grasping or visual servoing).

---

## 5. Typical workflows

### Workflow A: Record robot trajectories for training

1. Install and verify (Section 3).
2. (Optional) Hand-eye calibrate and save `calibration_info.json` (Section 4.4).
3. In your data-collection script:
   - `RealsenseD435i()` + `start_recording("path/to/trajectory.h5")`.
   - Each time you get a frame (e.g. with robot state), call `cam.get_frame()` so it’s written to HDF5.
   - On trajectory end: `stop_recording()`.
4. Later: load trajectories with `HDF5RecordingReader` and use with your training pipeline.

### Workflow B: Run DROID-SLAM (or similar) from the camera

1. `save_calibration("calib/realsense.txt")` once (Section 4.2).
2. Stream with `image_stream(..., as_tensor=True)` and call `droid.track(t, image, intrinsics)` in a loop.

### Workflow C: Visual servoing / grasping with eye-in-hand

1. Print Charuco board and run hand-eye calibration with real robot poses (Section 4.4 C).
2. Load `calibration_info.json` and get camera pose in gripper frame.
3. In your control loop: get image, detect object/target in image, compute 3D in camera frame, then transform to gripper/base using the saved pose and send commands to the robot.

---

## 6. Customization

- **Resolution / FPS:**  
  `RealsenseD435i(width=848, height=480, fps=30)` (or other supported modes).

- **No depth alignment:**  
  `align_depth_to_color=False` in `RealsenseD435i(...)`.

- **IMU (D435i):**  
  `RealsenseD435i(enable_imu=True)`. Frames still come from `get_frame()`; IMU can be read from the pipeline separately if needed.

- **Calibration board:**  
  In `hand_eye_calibration.py`, constants `CHARUCO_ROWS`, `CHARUCO_COLS`, `CHARUCO_SQUARE_LENGTH`, `CHARUCO_MARKER_LENGTH` must match your printed board.

---

## 7. Troubleshooting

| Issue | What to try |
|-------|--------------|
| Camera not found | Check USB, udev rules, `rs-enumerate-devices`. |
| `ImportError: pyrealsense2` | Install librealsense2 first, then `pip install pyrealsense2`. |
| `ImportError: cv2.aruco` | Use `opencv-contrib-python`, not only `opencv-python`. |
| Hand-eye “Calibration failed” | More samples (20+), board fully visible, varied poses. |
| Recording file empty or small | Ensure you call `get_frame()` in a loop while `start_recording()` is active. |

---

## 8. Quick reference

| Goal | Command or entry point |
|------|------------------------|
| Test camera | `python demo_capture.py` |
| Record to HDF5 | `python demo_record.py --record --path recordings/demo.h5` |
| Replay HDF5 | `python demo_record.py --replay --path recordings/demo.h5` |
| Generate Charuco | `python demo_calibration.py --generate-board` |
| Calibration demo | `python demo_calibration.py --mode hand --output calibration/calibration_info.json` |
| DROID calib file | In Python: `RealsenseD435i()` then `cam.save_calibration("calib.txt")` |

For API details (methods, arguments, return types), see **README.md** and the docstrings in `realsense_wrapper.py` and `hand_eye_calibration.py`.
