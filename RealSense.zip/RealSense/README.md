# RealSense D435i Camera Wrapper

A Python camera wrapper for the Intel RealSense D435i, designed for robot motion and pose capture. The interface is inspired by how the [DROID-SLAM](https://github.com/princeton-vl/DROID-SLAM) repository uses the ZED camera, enabling drop-in compatibility with SLAM and pose estimation pipelines.

**→ Full step-by-step guide: [USAGE.md](USAGE.md)** (installation, capture, recording, hand-eye calibration, workflows).

## Features

- **RGB-D capture** with depth aligned to color
- **HDF5 recording** (DROID SVO equivalent): `start_recording()` / `stop_recording()`
- **HDF5 playback** via `HDF5RecordingReader` (like DROID's SVOReader)
- **Hand-eye calibration** (Charuco + cv2.calibrateHandEye): eye-in-hand and eye-to-hand
- **Intrinsics** in DROID format `[fx, fy, cx, cy]` for SLAM compatibility
- **Calibration file export** for use with DROID-SLAM
- **`image_stream`** generator matching DROID-SLAM's interface: `(t, image, intrinsics)`
- Optional **IMU** support (D435i has accelerometer and gyroscope)
- Context manager for clean start/stop

## Installation

1. **Install librealsense2** (system-level):

   ```bash
   # Ubuntu: follow https://github.com/IntelRealSense/librealsense
   sudo apt-get install librealsense2-dev librealsense2-utils
   ```

2. **Install Python dependencies**:

   ```bash
   pip install -r requirements.txt
   ```

   Or directly:
   ```bash
   pip install pyrealsense2 numpy h5py opencv-python
   ```

## Usage

### Basic capture

```python
from realsense_wrapper import RealsenseD435i

with RealsenseD435i() as cam:
    for t, rgb, depth, intrinsics, ts in cam.stream():
        # Process rgb, depth, intrinsics
        print(f"Frame {t}: {rgb.shape}, intrinsics {intrinsics.to_array()}")
```

### DROID-SLAM compatible stream

```python
from realsense_wrapper import RealsenseD435i

with RealsenseD435i() as cam:
    # Yields (t, image, intrinsics) - same as DROID's image_stream
    for t, image, intrinsics in cam.image_stream(stride=3, as_tensor=True):
        # image: torch (3, H, W), intrinsics: torch [fx, fy, cx, cy]
        droid.track(t, image, intrinsics=intrinsics)
```

### Save calibration for DROID-SLAM

```python
with RealsenseD435i() as cam:
    cam.save_calibration("calib/realsense_d435i.txt")
```

Then run DROID-SLAM with `--calib=calib/realsense_d435i.txt`.

### HDF5 recording (DROID SVO equivalent)

```python
from realsense_wrapper import RealsenseD435i, HDF5RecordingReader

# Record
with RealsenseD435i() as cam:
    cam.start_recording("recordings/trajectory.h5")
    for _ in range(300):  # ~10 sec at 30fps
        cam.get_frame()   # frames auto-saved when recording
    cam.stop_recording()

# Playback
with HDF5RecordingReader("recordings/trajectory.h5") as reader:
    for t, rgb, depth, ts in reader.stream():
        process_frame(rgb, depth)
```

HDF5 layout: `observations/image`, `observations/depth`, `observations/timestamp`, `metadata/intrinsics`, etc.

### Custom resolution

```python
cam = RealsenseD435i(width=848, height=480, fps=30)
cam.start()
frame = cam.get_frame()
cam.stop()
```

### Hand-eye calibration

```python
from realsense_wrapper import RealsenseD435i
from hand_eye_calibration import HandCameraCalibrator, ThirdPersonCameraCalibrator, save_calibration_info

with RealsenseD435i() as cam:
    intr = cam.get_intrinsics()
    # Eye-in-hand: camera on gripper
    calibrator = HandCameraCalibrator(intr)
    # Add samples: (image, gripper_pose) with pose [x,y,z,rx,ry,rz]
    calibrator.add_sample("realsense", rgb, gripper_pose)
    result = calibrator.calibrate("realsense")  # camera pose in gripper frame
    save_calibration_info("calibration_info.json", "realsense", result)

# Eye-to-hand: use ThirdPersonCameraCalibrator for fixed camera
```

Generate Charuco board: `python demo_calibration.py --generate-board`

### With IMU (D435i)

```python
# IMU support can be added for sensor fusion
cam = RealsenseD435i(enable_imu=True)
cam.start()
# ... poll IMU via pipeline if needed
cam.stop()
```

## Demos

```bash
# Live RGB-D view
python demo_capture.py

# Record to HDF5 then replay (DROID SVO equivalent)
python demo_record.py --record --path recordings/demo.h5
python demo_record.py --replay --path recordings/demo.h5

# Hand-eye calibration (print Charuco board first, see demo_calibration.py)
python demo_calibration.py --mode hand --output calibration/calibration_info.json
```

## API Reference

| Method / Attribute | Description |
|--------------------|-------------|
| `RealsenseD435i(width, height, fps, ...)` | Create wrapper with stream config |
| `start()` / `stop()` | Start/stop pipeline |
| `get_frame()` | Capture single frame → `Frame` |
| `start_recording(path)` / `stop_recording()` | Record to HDF5 (like ZED SVO) |
| `is_recording()` | True if recording |
| `stream(stride)` | Generator: (t, rgb, depth, intrinsics, ts) |
| `image_stream(stride, as_tensor)` | DROID-style: (t, image, intrinsics) |
| `get_intrinsics()` | Return `Intrinsics` dataclass |
| `save_calibration(path)` | Save DROID-format calib file |
| `HDF5RecordingReader(filepath)` | Play back HDF5 recordings |
| `hand_eye_calibration.HandCameraCalibrator` | Eye-in-hand calibration |
| `hand_eye_calibration.ThirdPersonCameraCalibrator` | Eye-to-hand calibration |

## Comparison with ZED (DROID-style usage)

| ZED (pyzed)        | RealSense D435i (this wrapper)     |
|--------------------|------------------------------------|
| `zed.grab()`       | `get_frame()` / `stream()`         |
| `zed.retrieve_image()` | `frame.rgb`                    |
| `zed.retrieve_measure()` | `frame.depth` (aligned)      |
| `enable_recording()` / `disable_recording()` → .svo | `start_recording()` / `stop_recording()` → .h5 |
| SVOReader          | HDF5RecordingReader                |
| `camera_info.calibration` | `get_intrinsics()` / `save_calibration()` |
| Image dir + calib  | `image_stream()` + `save_calibration()` |

## License

MIT
