# Using TorchCodec for Replay

Replay uses LeRobot’s video decoder. The default is **TorchCodec** when it can load; otherwise **PyAV** is used. TorchCodec needs FFmpeg shared libraries in your environment.

## 1. Install FFmpeg in the same env as LeRobot (XARM7)

Install FFmpeg via conda so its shared libs (`libavutil`, etc.) are on the library path:

```bash
conda activate XARM7
conda install -c conda-forge ffmpeg
```

Check that the libs are in the env:

```bash
# Example (paths may differ)
ls $CONDA_PREFIX/lib/libavutil*
```

## 2. (Optional) Match TorchCodec to your PyTorch

Your PyTorch is 2.7.x. Use a TorchCodec build that matches:

- PyTorch 2.7 → e.g. `torchcodec` from PyPI or the [version table](https://github.com/pytorch/torchcodec?tab=readme-ov-file#installing-torchcodec).

Reinstall only if you get version errors:

```bash
pip install torchcodec
```

## 3. Run replay (default = TorchCodec when available)

```bash
python demo_soa_record.py --replay --path recordings/soa_demo3
```

If you still see TorchCodec/FFmpeg load errors, force PyAV:

```bash
python demo_soa_record.py --replay --path recordings/soa_demo3 --video-backend pyav
```

## 4. If libavutil still can’t be found

Conda’s FFmpeg must be visible at runtime. If you use a different env or run from a launcher, ensure the conda env is activated so `LD_LIBRARY_PATH` (or equivalent) includes `$CONDA_PREFIX/lib`. You can set it explicitly:

```bash
export LD_LIBRARY_PATH=$CONDA_PREFIX/lib:$LD_LIBRARY_PATH
python demo_soa_record.py --replay --path recordings/soa_demo3
```

## Summary

| Step | Command |
|------|--------|
| Install FFmpeg (conda) | `conda activate XARM7` then `conda install -c conda-forge ffmpeg` |
| Replay (TorchCodec) | `python demo_soa_record.py --replay --path recordings/soa_demo3` |
| Replay (force PyAV) | `python demo_soa_record.py --replay --path recordings/soa_demo3 --video-backend pyav` |
