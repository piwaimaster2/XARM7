#!/usr/bin/env python3
"""Demo: Live RGB-D capture with RealSense D435i wrapper."""

import cv2
import numpy as np

from realsense_wrapper import RealsenseD435i


def main():
    print("RealSense D435i demo - Press 'q' to quit")
    print("Intrinsics (fx, fy, cx, cy):")

    with RealsenseD435i() as cam:
        intr = cam.get_intrinsics()
        print(f"  {intr.to_array()}")

        for t, rgb, depth, intr, ts in cam.stream():
            # Colormap depth for visualization
            depth_vis = cv2.applyColorMap(
                cv2.convertScaleAbs(depth, alpha=0.03), cv2.COLORMAP_JET
            )
            combined = np.hstack((rgb, depth_vis))
            cv2.putText(
                combined,
                f"Frame {t}",
                (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 255, 0),
                2,
            )
            cv2.imshow("RealSense D435i - RGB | Depth", combined)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
