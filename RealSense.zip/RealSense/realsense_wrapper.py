"""
RealSense D435i Camera Wrapper for Robot Motion and Pose Capture

This wrapper provides an interface for capture of RGB, depth, and camera intrinsics
for motion tracking and pose estimation applications.

Interface mirrors DROID's ZED camera usage:
    - start_recording() / stop_recording() - record to HDF5 (RealSense equivalent of SVO)
    - Yields (t, image, depth, intrinsics, timestamp) for full capture
    - Intrinsics in format: [fx, fy, cx, cy] for compatibility with SLAM systems

Usage:
    # Basic capture
    with RealsenseD435i() as cam:
        for t, rgb, depth, intrinsics, ts in cam.stream():
            process_frame(rgb, depth, intrinsics)

    # DROID-style HDF5 recording (like ZED SVO)
    with RealsenseD435i() as cam:
        cam.start_recording("recordings/recording.h5")
        for _ in range(300):  # ~10 sec at 30fps
            cam.get_frame()  # frames auto-saved when recording
        cam.stop_recording()

    # Playback from HDF5
    reader = HDF5RecordingReader("recordings/recording.h5")
    for t, rgb, depth, ts in reader.stream():
        process_frame(rgb, depth)
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import Generator, Optional

import numpy as np

try:
    import pyrealsense2 as rs
except ImportError:
    raise ImportError(
        "pyrealsense2 is required. Install with: pip install pyrealsense2"
    )

try:
    import h5py
except ImportError:
    h5py = None


@dataclass
class Intrinsics:
    """Camera intrinsics in DROID/standard format."""

    fx: float
    fy: float
    cx: float
    cy: float
    width: int
    height: int
    distortion: Optional[np.ndarray] = None  # [k1, k2, p1, p2, k3, ...]

    def to_array(self) -> np.ndarray:
        """Return [fx, fy, cx, cy] for SLAM/calibration compatibility."""
        return np.array([self.fx, self.fy, self.cx, self.cy], dtype=np.float64)

    def to_droid_calib_line(self) -> str:
        """Return calibration file line in DROID format: fx fy cx cy [k1 k2 p1 p2 k3]."""
        line = f"{self.fx} {self.fy} {self.cx} {self.cy}"
        if self.distortion is not None and len(self.distortion) > 0:
            line += " " + " ".join(str(k) for k in self.distortion)
        return line

    @classmethod
    def from_rs_intrinsics(cls, intr: rs.intrinsics) -> "Intrinsics":
        """Create from pyrealsense2 intrinsics."""
        coeffs = np.array(intr.coeffs, dtype=np.float64) if intr.coeffs else None
        return cls(
            fx=float(intr.fx),
            fy=float(intr.fy),
            cx=float(intr.ppx),
            cy=float(intr.ppy),
            width=intr.width,
            height=intr.height,
            distortion=coeffs,
        )


@dataclass
class Frame:
    """Single captured frame with RGB, depth, and metadata."""

    timestamp: float
    frame_id: int
    rgb: np.ndarray  # (H, W, 3) BGR
    depth: np.ndarray  # (H, W) in meters
    intrinsics: Intrinsics
    depth_scale: float  # multiplier to convert depth units to meters

    @property
    def depth_meters(self) -> np.ndarray:
        """Depth in meters (depth * depth_scale if raw is in mm)."""
        return self.depth.astype(np.float32) * self.depth_scale


class RealsenseD435i:
    """
    RealSense D435i camera wrapper for robot motion and pose capture.

    Provides RGB-D capture with aligned depth, intrinsics, and optional IMU.
    Interface designed for compatibility with DROID-SLAM and similar pipelines.
    """

    DEFAULT_WIDTH = 640
    DEFAULT_HEIGHT = 480
    DEFAULT_FPS = 30

    def __init__(
        self,
        width: int = DEFAULT_WIDTH,
        height: int = DEFAULT_HEIGHT,
        fps: int = DEFAULT_FPS,
        align_depth_to_color: bool = True,
        enable_imu: bool = False,
    ):
        """
        Initialize the RealSense D435i wrapper.

        Args:
            width: Color/depth stream width.
            height: Color/depth stream height.
            fps: Frame rate.
            align_depth_to_color: If True, align depth to color frame (recommended).
            enable_imu: Enable IMU stream (D435i has accelerometer + gyroscope).
        """
        self.width = width
        self.height = height
        self.fps = fps
        self.align_depth_to_color = align_depth_to_color
        self.enable_imu = enable_imu

        self._pipeline: Optional[rs.pipeline] = None
        self._config: Optional[rs.config] = None
        self._align: Optional[rs.align] = None
        self._profile: Optional[rs.pipeline_profile] = None
        self._depth_scale: float = 0.001  # mm to meters
        self._intrinsics: Optional[Intrinsics] = None
        self._frame_count: int = 0

        # HDF5 recording (DROID SVO equivalent)
        self._recording_file = None
        self._recording_path: Optional[str] = None
        self._recording_datasets = {}

    def start(self) -> None:
        """Start the camera pipeline."""
        if self._pipeline is not None:
            return

        self._config = rs.config()
        self._config.enable_stream(
            rs.stream.depth, self.width, self.height, rs.format.z16, self.fps
        )
        self._config.enable_stream(
            rs.stream.color, self.width, self.height, rs.format.bgr8, self.fps
        )
        if self.enable_imu:
            self._config.enable_stream(rs.stream.accel)
            self._config.enable_stream(rs.stream.gyro)

        self._pipeline = rs.pipeline()
        self._profile = self._pipeline.start(self._config)

        # Get depth scale
        depth_sensor = self._profile.get_device().first_depth_sensor()
        self._depth_scale = depth_sensor.get_depth_scale()

        if self.align_depth_to_color:
            self._align = rs.align(rs.stream.color)

        # Extract intrinsics from color stream (after alignment, depth matches)
        color_profile = self._profile.get_stream(rs.stream.color)
        color_intr = color_profile.as_video_stream_profile().get_intrinsics()
        self._intrinsics = Intrinsics.from_rs_intrinsics(color_intr)

        self._frame_count = 0

    def stop(self) -> None:
        """Stop the camera pipeline."""
        self.stop_recording()
        if self._pipeline is not None:
            try:
                self._pipeline.stop()
            except RuntimeError:
                pass
            self._pipeline = None
        self._profile = None
        self._align = None

    def start_recording(self, filepath: str) -> None:
        """
        Start recording frames to HDF5 (RealSense equivalent of DROID's ZED SVO).

        Frames captured via get_frame() are automatically written. Structure:
            observations/image: (T, H, W, 3) uint8 BGR
            observations/depth: (T, H, W) uint16
            observations/timestamp: (T,) float64
            metadata/intrinsics: [fx, fy, cx, cy]
            metadata/depth_scale, width, height
        """
        if h5py is None:
            raise ImportError("h5py is required for recording. Install with: pip install h5py")
        if self._recording_file is not None:
            return
        if self._pipeline is None:
            raise RuntimeError("Camera not started. Call start() before start_recording().")

        parent = os.path.dirname(filepath)
        if parent:
            os.makedirs(parent, exist_ok=True)
        self._recording_path = filepath
        self._recording_file = h5py.File(filepath, "w")
        intr = self._intrinsics
        H, W = self.height, self.width

        # Create expandable datasets (DROID trajectory style)
        obs = self._recording_file.create_group("observations")
        obs.create_dataset(
            "image",
            shape=(1, H, W, 3),
            maxshape=(None, H, W, 3),
            dtype=np.uint8,
            compression="gzip",
            chunks=(1, H, W, 3),
        )
        obs.create_dataset(
            "depth",
            shape=(1, H, W),
            maxshape=(None, H, W),
            dtype=np.uint16,
            compression="gzip",
            chunks=(1, H, W),
        )
        obs.create_dataset(
            "timestamp",
            shape=(1,),
            maxshape=(None,),
            dtype=np.float64,
        )

        meta = self._recording_file.create_group("metadata")
        meta.create_dataset("intrinsics", data=intr.to_array())
        meta.create_dataset("depth_scale", data=np.array(self._depth_scale, dtype=np.float64))
        meta.create_dataset("width", data=np.array(W, dtype=np.int32))
        meta.create_dataset("height", data=np.array(H, dtype=np.int32))
        if intr.distortion is not None:
            meta.create_dataset("distortion", data=intr.distortion)

        self._recording_datasets = {
            "image": obs["image"],
            "depth": obs["depth"],
            "timestamp": obs["timestamp"],
        }

    def stop_recording(self) -> None:
        """Stop HDF5 recording and close the file."""
        if self._recording_file is None:
            return
        try:
            self._recording_file.flush()
            self._recording_file.close()
        except Exception:
            pass
        self._recording_file = None
        self._recording_path = None
        self._recording_datasets = {}

    def is_recording(self) -> bool:
        """Return True if currently recording to HDF5."""
        return self._recording_file is not None

    def __enter__(self) -> "RealsenseD435i":
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.stop()

    def get_frame(self, timeout_ms: int = 5000) -> Optional[Frame]:
        """
        Capture a single frame. Blocks until a frame is available.

        Returns:
            Frame with rgb, depth, intrinsics, or None if capture failed.
        """
        if self._pipeline is None:
            raise RuntimeError("Camera not started. Call start() or use context manager.")

        frames = self._pipeline.wait_for_frames(timeout_ms=timeout_ms)
        if not frames:
            return None

        if self._align is not None:
            frames = self._align.process(frames)

        depth_frame = frames.get_depth_frame()
        color_frame = frames.get_color_frame()
        if not depth_frame or not color_frame:
            return None

        rgb = np.asanyarray(color_frame.get_data())
        depth = np.asanyarray(depth_frame.get_data())
        ts = frames.get_timestamp() / 1000.0 if frames.get_timestamp() else time.time()

        self._frame_count += 1
        frame = Frame(
            timestamp=ts,
            frame_id=self._frame_count - 1,
            rgb=rgb,
            depth=depth,
            intrinsics=self._intrinsics,
            depth_scale=self._depth_scale,
        )

        # Append to HDF5 when recording (DROID SVO equivalent)
        if self._recording_file is not None:
            ds = self._recording_datasets
            t = frame.frame_id
            for key, data in [("image", rgb), ("depth", depth), ("timestamp", np.array([ts]))]:
                ds[key].resize(t + 1, axis=0)
                ds[key][t] = data

        return frame

    def stream(
        self, stride: int = 1
    ) -> Generator[tuple[int, np.ndarray, np.ndarray, Intrinsics, float], None, None]:
        """
        Generator yielding (frame_id, rgb, depth, intrinsics, timestamp).

        Similar to ZED's grab/retrieve loop, suitable for pose/SLAM pipelines.
        """
        while True:
            frame = self.get_frame()
            if frame is None:
                continue
            if (frame.frame_id % stride) == 0:
                yield (
                    frame.frame_id,
                    frame.rgb,
                    frame.depth,
                    frame.intrinsics,
                    frame.timestamp,
                )

    def image_stream(
        self,
        stride: int = 1,
        as_tensor: bool = False,
    ) -> Generator:
        """
        DROID-SLAM compatible image stream: yields (t, image, intrinsics).

        Args:
            stride: Yield every Nth frame.
            as_tensor: If True and torch is available, return image as (3,H,W) tensor.

        Yields:
            (t, image, intrinsics) where image is (H,W,3) or torch (3,H,W).
        """
        if as_tensor:
            try:
                import torch
            except ImportError:
                as_tensor = False

        for t, rgb, depth, intr, ts in self.stream(stride=stride):
            image = rgb
            if as_tensor:
                # DROID expects (C, H, W), uint8
                image = torch.as_tensor(image).permute(2, 0, 1)
            intrinsics = intr.to_array()
            if as_tensor:
                intrinsics = torch.as_tensor(intrinsics, dtype=torch.float64)
            yield t, image, intrinsics

    def get_intrinsics(self) -> Intrinsics:
        """Return camera intrinsics."""
        if self._intrinsics is None:
            raise RuntimeError("Camera not started or intrinsics not available.")
        return self._intrinsics

    def save_calibration(self, path: str) -> None:
        """
        Save calibration file in DROID format (fx fy cx cy [k1 k2 p1 p2 k3]).

        Usage with DROID-SLAM:
            python demo.py --imagedir=path/to/images --calib=path/to/calib.txt
        """
        intr = self.get_intrinsics()
        with open(path, "w") as f:
            f.write(intr.to_droid_calib_line() + "\n")


class HDF5RecordingReader:
    """
    Read RealSense HDF5 recordings (counterpart to DROID's SVOReader).

    Provides playback of recordings created by RealsenseD435i.start_recording().
    """

    def __init__(self, filepath: str):
        if h5py is None:
            raise ImportError("h5py is required. Install with: pip install h5py")
        self._file = h5py.File(filepath, "r")
        self._observations = self._file["observations"]
        self._metadata = self._file["metadata"]
        self._length = len(self._observations["timestamp"])
        self._index = 0

    def get_frame_count(self) -> int:
        """Return total number of frames."""
        return self._length

    def get_frame_resolution(self) -> tuple[int, int]:
        """Return (width, height)."""
        w = int(self._metadata["width"][()])
        h = int(self._metadata["height"][()])
        return (w, h)

    def get_intrinsics(self) -> Intrinsics:
        """Return camera intrinsics from recording."""
        arr = self._metadata["intrinsics"][()]
        scale = float(self._metadata["depth_scale"][()])
        w = int(self._metadata["width"][()])
        h = int(self._metadata["height"][()])
        dist = None
        if "distortion" in self._metadata:
            dist = np.array(self._metadata["distortion"][()])
        return Intrinsics(
            fx=float(arr[0]),
            fy=float(arr[1]),
            cx=float(arr[2]),
            cy=float(arr[3]),
            width=w,
            height=h,
            distortion=dist,
        )

    def set_frame_index(self, index: int) -> None:
        """Seek to frame index."""
        self._index = max(0, min(index, self._length - 1))

    def read_camera(
        self,
        index: Optional[int] = None,
        return_timestamp: bool = False,
    ):
        """
        Read a single frame. Similar to DROID SVOReader.read_camera().

        Returns:
            If return_timestamp=False: dict with "image", "depth" keys
            If return_timestamp=True: (data_dict, timestamp)
        """
        if index is not None:
            self._index = index
        if self._index >= self._length:
            return None

        i = self._index
        self._index += 1

        rgb = np.array(self._observations["image"][i])
        depth = np.array(self._observations["depth"][i])
        ts = float(self._observations["timestamp"][i])

        data_dict = {"image": rgb, "depth": depth}
        if return_timestamp:
            return data_dict, ts
        return data_dict

    def stream(
        self, stride: int = 1
    ) -> Generator[tuple[int, np.ndarray, np.ndarray, float], None, None]:
        """Generator yielding (frame_id, rgb, depth, timestamp)."""
        for t in range(0, self._length, stride):
            out = self.read_camera(index=t, return_timestamp=True)
            if out is None:
                break
            data_dict, ts = out
            yield t, data_dict["image"], data_dict["depth"], ts

    def close(self) -> None:
        """Close the HDF5 file."""
        if self._file is not None:
            self._file.close()
            self._file = None

    def __enter__(self) -> "HDF5RecordingReader":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
