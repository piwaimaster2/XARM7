# ROBOT SPECIFIC IMPORTS
import os
import threading
import time

#import grpc
import numpy as np
#import torch
#from polymetis import GripperInterface, RobotInterface

#from droid.misc.parameters import sudo_password
#from droid.misc.subprocess_utils import run_terminal_command, run_threaded_command

# UTILITY SPECIFIC IMPORTS
from droid.misc.transformations import add_poses, euler_to_quat, pose_diff, quat_to_euler
from droid.robot_ik.robot_ik_solver import RobotIKSolver
from droid.robot_ik.velocity_scaling import VelocityScaling

"""
class FrankaRobot:
    def launch_controller(self):
        try:
            self.kill_controller()
        except:
            pass

        dir_path = os.path.dirname(os.path.realpath(__file__))
        self._robot_process = run_terminal_command(
            "echo " + sudo_password + " | sudo -S " + "bash " + dir_path + "/launch_robot.sh"
        )
        self._gripper_process = run_terminal_command(
            "echo " + sudo_password + " | sudo -S " + "bash " + dir_path + "/launch_gripper.sh"
        )
        self._server_launched = True
        time.sleep(5)

    def launch_robot(self):
        self._robot = RobotInterface(ip_address="localhost")
        self._gripper = GripperInterface(ip_address="localhost")
        self._max_gripper_width = self._gripper.metadata.max_width
        self._ik_solver = RobotIKSolver()
        self._controller_not_loaded = False

    def kill_controller(self):
        self._robot_process.kill()
        self._gripper_process.kill()

    def update_command(self, command, action_space="cartesian_velocity", gripper_action_space=None, blocking=False):
        action_dict = self.create_action_dict(command, action_space=action_space, gripper_action_space=gripper_action_space)

        self.update_joints(action_dict["joint_position"], velocity=False, blocking=blocking)
        self.update_gripper(action_dict["gripper_position"], velocity=False, blocking=blocking)

        return action_dict

    def update_pose(self, command, velocity=False, blocking=False):
        if blocking:
            if velocity:
                curr_pose = self.get_ee_pose()
                cartesian_delta = self._scaling.cartesian_velocity_to_delta(command)
                command = add_poses(cartesian_delta, curr_pose)

            pos = torch.Tensor(command[:3])
            quat = torch.Tensor(euler_to_quat(command[3:6]))
            curr_joints = self._robot.get_joint_positions()
            desired_joints = self._robot.solve_inverse_kinematics(pos, quat, curr_joints)
            self.update_joints(desired_joints, velocity=False, blocking=True)
        else:
            if not velocity:
                curr_pose = self.get_ee_pose()
                cartesian_delta = pose_diff(command, curr_pose)
                command = self._scaling.cartesian_delta_to_velocity(cartesian_delta)

            robot_state = self.get_robot_state()[0]
            joint_velocity = self._ik_solver.cartesian_velocity_to_joint_velocity(command, robot_state=robot_state)

            self.update_joints(joint_velocity, velocity=True, blocking=False)

    def update_joints(self, command, velocity=False, blocking=False, cartesian_noise=None):
        if cartesian_noise is not None:
            command = self.add_noise_to_joints(command, cartesian_noise)
        command = torch.Tensor(command)

        if velocity:
            joint_delta = self._scaling.joint_velocity_to_delta(command)
            command = joint_delta + self._robot.get_joint_positions()

        def helper_non_blocking():
            if not self._robot.is_running_policy():
                self._controller_not_loaded = True
                self._robot.start_cartesian_impedance()
                timeout = time.time() + 5
                while not self._robot.is_running_policy():
                    time.sleep(0.01)
                    if time.time() > timeout:
                        self._robot.start_cartesian_impedance()
                        timeout = time.time() + 5

                self._controller_not_loaded = False
            try:
                self._robot.update_desired_joint_positions(command)
            #except grpc.RpcError:
                #pass

        if blocking:
            if self._robot.is_running_policy():
                self._robot.terminate_current_policy()
            try:
                time_to_go = self.adaptive_time_to_go(command)
                self._robot.move_to_joint_positions(command, time_to_go=time_to_go)
            #except grpc.RpcError:
                #pass

            self._robot.start_cartesian_impedance()
        else:
            if not self._controller_not_loaded:
                run_threaded_command(helper_non_blocking)

    def update_gripper(self, command, velocity=True, blocking=False):
        if velocity:
            gripper_delta = self._scaling.gripper_velocity_to_delta(command)
            command = gripper_delta + self.get_gripper_position()

        command = float(np.clip(command, 0, 1))
        self._gripper.goto(width=self._max_gripper_width * (1 - command), speed=0.05, force=0.1, blocking=blocking)

    def add_noise_to_joints(self, original_joints, cartesian_noise):
        original_joints = torch.Tensor(original_joints)

        pos, quat = self._robot.robot_model.forward_kinematics(original_joints)
        curr_pose = pos.tolist() + quat_to_euler(quat).tolist()
        new_pose = add_poses(cartesian_noise, curr_pose)

        new_pos = torch.Tensor(new_pose[:3])
        new_quat = torch.Tensor(euler_to_quat(new_pose[3:]))

        noisy_joints, success = self._robot.solve_inverse_kinematics(new_pos, new_quat, original_joints)

        if success:
            desired_joints = noisy_joints
        else:
            desired_joints = original_joints

        return desired_joints.tolist()

    def get_joint_positions(self):
        return self._robot.get_joint_positions().tolist()

    def get_joint_velocities(self):
        return self._robot.get_joint_velocities().tolist()

    def get_gripper_position(self):
        return 1 - (self._gripper.get_state().width / self._max_gripper_width)

    def get_ee_pose(self):
        pos, quat = self._robot.get_ee_pose()
        angle = quat_to_euler(quat.numpy())
        return np.concatenate([pos, angle]).tolist()

    def get_robot_state(self):
        robot_state = self._robot.get_robot_state()
        gripper_position = self.get_gripper_position()
        pos, quat = self._robot.robot_model.forward_kinematics(torch.Tensor(robot_state.joint_positions))
        cartesian_position = pos.tolist() + quat_to_euler(quat.numpy()).tolist()

        state_dict = {
            "cartesian_position": cartesian_position,
            "gripper_position": gripper_position,
            "joint_positions": list(robot_state.joint_positions),
            "joint_velocities": list(robot_state.joint_velocities),
            "joint_torques_computed": list(robot_state.joint_torques_computed),
            "prev_joint_torques_computed": list(robot_state.prev_joint_torques_computed),
            "prev_joint_torques_computed_safened": list(robot_state.prev_joint_torques_computed_safened),
            "motor_torques_measured": list(robot_state.motor_torques_measured),
            "prev_controller_latency_ms": robot_state.prev_controller_latency_ms,
            "prev_command_successful": robot_state.prev_command_successful,
        }

        timestamp_dict = {
            "robot_timestamp_seconds": robot_state.timestamp.seconds,
            "robot_timestamp_nanos": robot_state.timestamp.nanos,
        }

        return state_dict, timestamp_dict

    def adaptive_time_to_go(self, desired_joint_position, t_min=0, t_max=4):
        curr_joint_position = self._robot.get_joint_positions()
        displacement = desired_joint_position - curr_joint_position
        time_to_go = self._robot._adaptive_time_to_go(displacement)
        clamped_time_to_go = min(t_max, max(time_to_go, t_min))
        return clamped_time_to_go

    def create_action_dict(self, action, action_space, gripper_action_space=None, robot_state=None):
        assert action_space in ["cartesian_position", "joint_position", "cartesian_velocity", "joint_velocity"]
        if robot_state is None:
            robot_state = self.get_robot_state()[0]
        action_dict = {"robot_state": robot_state}
        velocity = "velocity" in action_space

        if gripper_action_space is None:
            gripper_action_space = "velocity" if velocity else "position"
        assert gripper_action_space in ["velocity", "position"]
            

        if gripper_action_space == "velocity":
            action_dict["gripper_velocity"] = action[-1]
            gripper_delta = self._scaling.gripper_velocity_to_delta(action[-1])
            gripper_position = robot_state["gripper_position"] + gripper_delta
            action_dict["gripper_position"] = float(np.clip(gripper_position, 0, 1))
        else:
            action_dict["gripper_position"] = float(np.clip(action[-1], 0, 1))
            gripper_delta = action_dict["gripper_position"] - robot_state["gripper_position"]
            gripper_velocity = self._ik_solver.gripper_delta_to_velocity(gripper_delta)
            action_dict["gripper_delta"] = gripper_velocity

        if "cartesian" in action_space:
            if velocity:
                action_dict["cartesian_velocity"] = action[:-1]
                cartesian_delta = self._scaling.cartesian_velocity_to_delta(action[:-1])
                action_dict["cartesian_position"] = add_poses(
                    cartesian_delta, robot_state["cartesian_position"]
                ).tolist()
            else:
                action_dict["cartesian_position"] = action[:-1]
                cartesian_delta = pose_diff(action[:-1], robot_state["cartesian_position"])
                cartesian_velocity = self._scaling.cartesian_delta_to_velocity(cartesian_delta)
                action_dict["cartesian_velocity"] = cartesian_velocity.tolist()

            action_dict["joint_velocity"] = self._ik_solver.cartesian_velocity_to_joint_velocity(
                action_dict["cartesian_velocity"], robot_state=robot_state
            ).tolist()
            joint_delta = self._ik_solver.joint_velocity_to_delta(action_dict["joint_velocity"])
            action_dict["joint_position"] = (joint_delta + np.array(robot_state["joint_positions"])).tolist()

        if "joint" in action_space:
            # NOTE: Joint to Cartesian has undefined dynamics due to IK
            if velocity:
                action_dict["joint_velocity"] = action[:-1]
                joint_delta = self._ik_solver.joint_velocity_to_delta(action[:-1])
                action_dict["joint_position"] = (joint_delta + np.array(robot_state["joint_positions"])).tolist()
            else:
                action_dict["joint_position"] = action[:-1]
                joint_delta = np.array(action[:-1]) - np.array(robot_state["joint_positions"])
                joint_velocity = self._scaling.joint_delta_to_velocity(joint_delta)
                action_dict["joint_velocity"] = joint_velocity.tolist()

        return action_dict
"""

# -----------------------------------------------------------------------------
# XARM7 robot class (same interface as FrankaRobot, using xArm-Python-SDK)
# -----------------------------------------------------------------------------

def _get_xarm_ip():
    return os.environ.get("XARM_IP", "192.168.1.215")


def _get_xarm_protocol():
    """Protocol identifier (1, 2, or 3). Some gripper features require protocol 3."""
    val = os.environ.get("XARM_PROTOCOL", "")
    try:
        return int(val) if val else None
    except ValueError:
        return None


class XARM7:
    """xArm 7-DOF robot interface with same sub-functions as FrankaRobot.
    Uses xArm-Python-SDK; pose in meters and radians to match droid convention.
    """

    # xArm7 joint limits (rad). Use conservative limits for J1,J3,J5,J7 to match
    # firmware (specs say ±360° but firmware can reject e.g. |angle| > ~2.5).
    # J2,J4,J6 from specs: -117~116°, -6~225°, -97~180°.
    _JOINT_LIMITS_LOW = np.array([
        -2.5, -117 * np.pi / 180, -2.5, -6 * np.pi / 180,
        -2.5, -97 * np.pi / 180, -2.5,
    ])
    _JOINT_LIMITS_HIGH = np.array([
        2.5, 116 * np.pi / 180, 2.5, 225 * np.pi / 180,
        2.5, 180 * np.pi / 180, 2.5,
    ])

    # Servo mode (mode 1) switch: minimal delay so we don't add wait between updates.
    _SERVO_MODE_SWITCH_DELAY_S = 0.02
    _SERVO_MODE_WAIT_TIMEOUT_S = 0.2
    _SERVO_MODE_POLL_INTERVAL_S = 0.02

    def __init__(self, ip=None):
        self._ip = ip or _get_xarm_ip()
        self._arm = None
        self._server_launched = False
        self._max_gripper_pos = 1000  # xArm gripper 0=open, 1000=closed
        #self._ik_solver = RobotIKSolver()
        self._servo_mode = False  # True when in mode 1 for non-blocking motion
        self._last_servo_target = None  # last joint position sent by heartbeat (for cache + step calculation)
        # Cached state to avoid get_robot_state() every step (reduces tiny stops between updates).
        self._last_cartesian_cached = None
        self._last_gripper_cached = None
        # Background heartbeat: main thread writes target here, background thread sends tiny steps at 250Hz.
        self._shared_target_joints = None  # 7D array; protected by _shared_target_lock
        self._shared_target_lock = threading.Lock()
        self._heartbeat_thread = None
        self._heartbeat_running = False
        self._heartbeat_paused = False  # True during blocking moves so heartbeat does not send

    def launch_controller(self):
        # xArm has no local controller to launch; connection is via IP
        try:
            self.kill_controller()
        except Exception:
            pass
        self._server_launched = True

    def launch_robot(self, ip=None):
        ip = ip or self._ip
        try:
            from xarm.wrapper import XArmAPI
        except ImportError:
            raise ImportError("xArm-Python-SDK is required. Install with: pip install xarm-python-sdk")
        self._arm = XArmAPI(port=ip, baud_checkset=False, is_radian=True)
        self._arm.connect()
        # Phase 2: Attempt to set protocol 3 if XARM_PROTOCOL=3 (gripper may require it; see docs/XARM_GRIPPER_PROTOCOL.md)
        protocol = _get_xarm_protocol()
        if protocol is not None:
            try:
                methods_to_try = [
                    getattr(self._arm, "set_protocol", None),
                    getattr(self._arm, "config_protocol_identifier", None),
                ]
                if hasattr(self._arm, "arm"):
                    methods_to_try.append(getattr(self._arm.arm, "set_protocol", None))
                for meth in methods_to_try:
                    if callable(meth):
                        meth(protocol)
                        break
            except Exception:
                pass
        self._arm.motion_enable(enable=True)
        self._arm.set_mode(0)
        self._arm.set_state(state=0)
        # Phase 1: Enable gripper and set location mode (required for set_gripper_position to take effect)
        time.sleep(0.5)
        try:
            self._arm.set_gripper_mode(0)  # 0 = location/position mode
            self._arm.set_gripper_enable(True)
        except Exception as e:
            pass  # Robot may not have gripper; continue without failing
        self._scaling = VelocityScaling()
        # Initialize shared target from current position and start 250Hz heartbeat thread.
        code, angles = self._arm.get_servo_angle(is_radian=True)
        init_joints = list(angles)[:7] if code == 0 and angles else [0.0] * 7
        with self._shared_target_lock:
            self._shared_target_joints = np.array(init_joints, dtype=float)
        self._last_servo_target = np.array(init_joints, dtype=float)
        self._heartbeat_paused = False
        self._heartbeat_running = True
        self._heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
        self._heartbeat_thread.start()

    def kill_controller(self):
        self._heartbeat_running = False
        if self._heartbeat_thread is not None:
            self._heartbeat_thread.join(timeout=1.0)
            self._heartbeat_thread = None
        if self._arm is not None:
            try:
                self._arm.disconnect()
            except Exception:
                pass
        self._server_launched = False

    # Heartbeat runs at 250Hz (4ms). Step factor per tick: move this fraction of the way toward target.
    _HEARTBEAT_HZ = 250
    _HEARTBEAT_STEP_ALPHA = 0.15  # per-tick step toward target (0.15 = ~15% of gap per 4ms)

    def _heartbeat_loop(self):
        """Background thread: every 4ms read shared target, take a tiny step toward it, send to xArm."""
        interval = 1.0 / self._HEARTBEAT_HZ
        while self._heartbeat_running and self._arm is not None:
            loop_start = time.monotonic()
            if self._heartbeat_paused:
                time.sleep(interval)
                continue
            self._ensure_servo_mode()
            with self._shared_target_lock:
                target = np.array(self._shared_target_joints, dtype=float) if self._shared_target_joints is not None else None
            if target is None:
                time.sleep(interval)
                continue
            current = self._last_servo_target if self._last_servo_target is not None else np.array(target, dtype=float)
            step = current + self._HEARTBEAT_STEP_ALPHA * (target - current)
            step = np.clip(step, self._JOINT_LIMITS_LOW, self._JOINT_LIMITS_HIGH)
            try:
                self._arm.set_servo_angle_j(step.tolist(), is_radian=True)
                self._last_servo_target = np.array(step, dtype=float)
            except Exception:
                pass
            elapsed = time.monotonic() - loop_start
            if elapsed < interval:
                time.sleep(interval - elapsed)

    def _ensure_position_mode(self):
        if self._servo_mode and self._arm is not None:
            self._arm.set_mode(0)
            self._arm.set_state(state=0)
            self._servo_mode = False
            self._last_servo_target = None

    def _ensure_servo_mode(self):
        if self._arm is None:
            return
        if not self._servo_mode:
            self._arm.set_mode(1)
            self._arm.set_state(state=0)  # required for code 9: "state is not ready to move"
            # Give controller time to apply mode/state before first set_servo_angle_j.
            time.sleep(self._SERVO_MODE_SWITCH_DELAY_S)
            # Wait until SDK reports mode 1 to avoid "mode may be incorrect, mode: 1 (0)" and code 9.
            deadline = time.monotonic() + self._SERVO_MODE_WAIT_TIMEOUT_S
            while time.monotonic() < deadline:
                if getattr(self._arm, "mode", 0) == 1:
                    break
                time.sleep(self._SERVO_MODE_POLL_INTERVAL_S)
            else:
                # Timeout: continue anyway; first set_servo_angle_j may still work or retry will re-ensure.
                pass  # Optional: log "xArm servo mode wait timeout" if needed
            self._servo_mode = True

    def update_command(self, command, action_space="cartesian_velocity", gripper_action_space=None, blocking=False, dt=None):
        action_dict = self.create_action_dict(
            command, action_space=action_space, gripper_action_space=gripper_action_space, dt=dt
        )
        # Keep cache for next step so we can skip get_robot_state() and reduce wait between updates.
        if "cartesian_position" in action_dict:
            self._last_cartesian_cached = action_dict["cartesian_position"]
        self.update_joints(action_dict["joint_position"], velocity=False, blocking=blocking, dt=dt)
        self.update_gripper(action_dict["gripper_position"], velocity=False, blocking=blocking, dt=dt)
        return action_dict

    def update_pose(self, command, velocity=False, blocking=False):
        if blocking:
            self._ensure_position_mode()
            if velocity:
                curr_pose = self.get_ee_pose()
                cartesian_delta = self._scaling.cartesian_velocity_to_delta(command)
                command = add_poses(cartesian_delta, curr_pose)
            # command is [x,y,z,roll,pitch,yaw] in m and rad
            pose_mm = [command[0] * 1000, command[1] * 1000, command[2] * 1000, command[3], command[4], command[5]]
            code, angles = self._arm.get_inverse_kinematics(
                pose_mm, input_is_radian=True, return_is_radian=True
            )
            if code == 0 and angles:
                self.update_joints(angles[:7], velocity=False, blocking=True)
            else:
                # fallback: move joints to current (no move)
                pass
        else:
            if not velocity:
                curr_pose = self.get_ee_pose()
                cartesian_delta = pose_diff(command, curr_pose)
                command = self._scaling.cartesian_delta_to_velocity(cartesian_delta)
            robot_state = self.get_robot_state()[0]
            joint_velocity = self._cartesian_velocity_to_joint_velocity_xarm(command, robot_state)
            self.update_joints(joint_velocity, velocity=True, blocking=False)

    def update_joints(self, command, velocity=False, blocking=False, cartesian_noise=None, dt=None):
        if cartesian_noise is not None:
            command = self.add_noise_to_joints(command, cartesian_noise)
        command = np.array(command, dtype=float)
        if velocity:
            joint_delta = self._scaling.joint_velocity_to_delta(command, dt=dt)
            curr = self.get_joint_positions()
            command = joint_delta + np.array(curr)

        command = np.clip(command, self._JOINT_LIMITS_LOW, self._JOINT_LIMITS_HIGH)

        if blocking:
            self._heartbeat_paused = True
            try:
                self._ensure_position_mode()
                self._arm.set_servo_angle(
                    angle=command.tolist(),
                    is_radian=True,
                    wait=True,
                    timeout=10,
                )
            finally:
                self._last_servo_target = np.array(command, dtype=float)
                with self._shared_target_lock:
                    self._shared_target_joints = np.array(command, dtype=float)
                self._heartbeat_paused = False
        else:
            # Main thread (e.g. VR at 90Hz): only update shared target; heartbeat thread sends at 250Hz.
            with self._shared_target_lock:
                self._shared_target_joints = np.array(command, dtype=float)

    def ensure_gripper_enabled(self):
        """Enable gripper if not already (idempotent). Required for set_gripper_position to take effect."""
        try:
            self._arm.set_gripper_enable(True)
        except Exception:
            pass

    def update_gripper(self, command, velocity=True, blocking=False, dt=None):
        if velocity:
            gripper_delta = self._scaling.gripper_velocity_to_delta(command, dt=dt)
            command = gripper_delta + self.get_gripper_position()
        command = float(np.clip(command, 0, 1))
        self._last_gripper_cached = command
        pos = int(round(command * self._max_gripper_pos))
        self._arm.set_gripper_position(pos, wait=blocking, speed=1000)

    def add_noise_to_joints(self, original_joints, cartesian_noise):
        original_joints = np.array(original_joints)
        code, curr_pose = self._arm.get_forward_kinematics(
            original_joints.tolist(), input_is_radian=True, return_is_radian=True
        )
        if code != 0 or not curr_pose:
            return original_joints.tolist()
        # curr_pose [x,y,z,roll,pitch,yaw] in mm and rad
        curr_pose_m = [curr_pose[0] / 1000, curr_pose[1] / 1000, curr_pose[2] / 1000] + curr_pose[3:6]
        new_pose = add_poses(cartesian_noise, curr_pose_m)
        pose_mm = [new_pose[0] * 1000, new_pose[1] * 1000, new_pose[2] * 1000, new_pose[3], new_pose[4], new_pose[5]]
        code, angles = self._arm.get_inverse_kinematics(
            pose_mm, input_is_radian=True, return_is_radian=True
        )
        if code == 0 and angles:
            clipped = np.clip(angles, self._JOINT_LIMITS_LOW, self._JOINT_LIMITS_HIGH)
            # If IK solution was out of range, keep current joints to avoid a distorted move (Path A fix).
            if np.any(clipped != angles):
                return original_joints.tolist()
            return clipped.tolist()
        return original_joints.tolist()

    def get_joint_positions(self):
        code, angles = self._arm.get_servo_angle(is_radian=True)
        if code == 0 and angles:
            return list(angles)[:7]
        return [0.0] * 7

    def get_joint_velocities(self):
        code, result = self._arm.get_joint_states(is_radian=True, num=3)
        if code == 0 and result and len(result) >= 2:
            return list(result[1])[:7]
        return [0.0] * 7

    def get_gripper_position(self):
        code, pos = self._arm.get_gripper_position()
        normalized = float(np.clip(pos / self._max_gripper_pos, 0, 1)) if (code == 0 and pos is not None) else 0.0
        return normalized

    def get_ee_pose(self):
        code, pos = self._arm.get_position(is_radian=True)
        if code == 0 and pos and len(pos) >= 6:
            return [pos[0] / 1000, pos[1] / 1000, pos[2] / 1000, pos[3], pos[4], pos[5]]
        return [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

    def get_robot_state(self):
        code, joint_result = self._arm.get_joint_states(is_radian=True, num=3)
        positions = list(joint_result[0])[:7] if code == 0 and joint_result else [0.0] * 7
        velocities = list(joint_result[1])[:7] if code == 0 and len(joint_result) >= 2 else [0.0] * 7
        efforts = list(joint_result[2])[:7] if code == 0 and len(joint_result) >= 3 else [0.0] * 7

        code, pos = self._arm.get_position(is_radian=True)
        if code == 0 and pos and len(pos) >= 6:
            cartesian_position = [pos[0] / 1000, pos[1] / 1000, pos[2] / 1000, pos[3], pos[4], pos[5]]
        else:
            cartesian_position = [0.0] * 6

        gripper_position = self.get_gripper_position()

        state_dict = {
            "cartesian_position": cartesian_position,
            "gripper_position": gripper_position,
            "joint_positions": positions,
            "joint_velocities": velocities,
            "joint_torques_computed": efforts,
            "prev_joint_torques_computed": efforts,
            "prev_joint_torques_computed_safened": efforts,
            "motor_torques_measured": efforts,
            "prev_controller_latency_ms": 0,
            "prev_command_successful": True,
        }
        timestamp_dict = {
            "robot_timestamp_seconds": 0,
            "robot_timestamp_nanos": 0,
        }
        return state_dict, timestamp_dict

    def adaptive_time_to_go(self, desired_joint_position, t_min=0, t_max=4):
        curr = np.array(self.get_joint_positions())
        desired = np.array(desired_joint_position)
        displacement = np.abs(desired - curr)
        max_speed = 0.5  # rad/s
        time_to_go = float(np.max(displacement) / max_speed) if np.any(displacement) else 0
        return min(t_max, max(time_to_go, t_min))

    def _cartesian_velocity_to_joint_velocity_xarm(self, cartesian_velocity, robot_state):
        """Use xArm built-in IK to convert cartesian velocity to joint velocity."""
        cartesian_delta = self._scaling.cartesian_velocity_to_delta(cartesian_velocity)
        target_cartesian = add_poses(cartesian_delta, robot_state["cartesian_position"])
        pose_mm = [
            target_cartesian[0] * 1000,
            target_cartesian[1] * 1000,
            target_cartesian[2] * 1000,
            target_cartesian[3],
            target_cartesian[4],
            target_cartesian[5],
        ]
        code, angles = self._arm.get_inverse_kinematics(
            pose_mm, input_is_radian=True, return_is_radian=True
        )
        if code != 0 or not angles:
            return np.array(robot_state["joint_velocities"])
        joint_delta = np.array(angles[:7]) - np.array(robot_state["joint_positions"])
        return self._scaling.joint_delta_to_velocity(joint_delta)

    def create_action_dict(self, action, action_space, gripper_action_space=None, robot_state=None, dt=None):
        assert action_space in ["cartesian_position", "joint_position", "cartesian_velocity", "joint_velocity"]
        # In velocity stepping (dt set), use cached state when available to avoid get_robot_state() round-trips and reduce tiny stops.
        use_cache = (
            dt is not None
            and self._last_servo_target is not None
            and (self._last_cartesian_cached is not None if "cartesian" in action_space else True)
        )
        if robot_state is None:
            if use_cache:
                robot_state = {
                    "joint_positions": list(self._last_servo_target),
                    "cartesian_position": self._last_cartesian_cached if "cartesian" in action_space else (self._last_cartesian_cached or [0.0] * 6),
                    "gripper_position": self._last_gripper_cached if self._last_gripper_cached is not None else 0.0,
                    # Required when IK fails in _cartesian_velocity_to_joint_velocity_xarm (fallback uses joint_velocities).
                    "joint_velocities": [0.0] * 7,
                }
            else:
                robot_state = self.get_robot_state()[0]
                self._last_cartesian_cached = robot_state["cartesian_position"]
                self._last_gripper_cached = robot_state["gripper_position"]
        action_dict = {"robot_state": robot_state}
        velocity = "velocity" in action_space

        if gripper_action_space is None:
            gripper_action_space = "velocity" if velocity else "position"
        assert gripper_action_space in ["velocity", "position"]

        if gripper_action_space == "velocity":
            action_dict["gripper_velocity"] = action[-1]
            gripper_delta = self._scaling.gripper_velocity_to_delta(action[-1], dt=dt)
            gripper_position = robot_state["gripper_position"] + gripper_delta
            action_dict["gripper_position"] = float(np.clip(gripper_position, 0, 1))
        else:
            action_dict["gripper_position"] = float(np.clip(action[-1], 0, 1))
            gripper_delta = action_dict["gripper_position"] - robot_state["gripper_position"]
            gripper_velocity = self._scaling.gripper_delta_to_velocity(gripper_delta)
            action_dict["gripper_delta"] = gripper_velocity
        if "cartesian" in action_space:
            if velocity:
                action_dict["cartesian_velocity"] = action[:-1]
                cartesian_delta = self._scaling.cartesian_velocity_to_delta(action[:-1], dt=dt)
                action_dict["cartesian_position"] = add_poses(
                    cartesian_delta, robot_state["cartesian_position"]
                ).tolist()
            else:
                action_dict["cartesian_position"] = action[:-1]
                cartesian_delta = pose_diff(action[:-1], robot_state["cartesian_position"])
                cartesian_velocity = self._scaling.cartesian_delta_to_velocity(cartesian_delta)
                action_dict["cartesian_velocity"] = cartesian_velocity.tolist()

            action_dict["joint_velocity"] = self._cartesian_velocity_to_joint_velocity_xarm(
                action_dict["cartesian_velocity"], robot_state=robot_state
            ).tolist()
            joint_delta = self._scaling.joint_velocity_to_delta(action_dict["joint_velocity"], dt=dt)
            action_dict["joint_position"] = (
                joint_delta + np.array(robot_state["joint_positions"])
            ).tolist()

        if "joint" in action_space:
            if velocity:
                action_dict["joint_velocity"] = action[:-1]
                joint_delta = self._scaling.joint_velocity_to_delta(action[:-1], dt=dt)
                action_dict["joint_position"] = (
                    joint_delta + np.array(robot_state["joint_positions"])
                ).tolist()
            else:
                action_dict["joint_position"] = action[:-1]
                joint_delta = np.array(action[:-1]) - np.array(robot_state["joint_positions"])
                joint_velocity = self._scaling.joint_delta_to_velocity(joint_delta)
                action_dict["joint_velocity"] = joint_velocity.tolist()

        return action_dict
