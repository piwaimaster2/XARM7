# State–Observation–Action (S-O-A) Data Collection — Implementation Plan

This plan extends your existing RealSense + HDF5 pipeline so each timestep stores **State**, **Observation**, and **Action** in a single, index-aligned sequence (e.g. for imitation learning, world models, or RL).

---

## 1. Definitions (aligned with your stack)

| Term | Meaning in this pipeline | Source |
|------|--------------------------|--------|
| **State (S)** | Robot state at time `t`: e.g. EE pose in base frame `[x,y,z,rx,ry,rz]`, optional joint positions, gripper width. | Your robot API (or demo/synthetic for testing). |
| **Observation (O)** | Sensor reading at time `t`: RGB, depth, timestamps. Optionally IMU. | RealSense (already in `observations/`). |
| **Action (A)** | Command or executed change from `t` → `t+1`. Common choices: (a) **commanded action** (target pose / delta / joint cmd), or (b) **executed action** = `state_{t+1} - state_t`. | Robot API (command) or derived from state sequence. |

**Index alignment:** For each integer step `t` you store:
- `state[t]` = robot state when observation `t` was taken  
- `observation[t]` = image/depth/timestamp at `t`  
- `action[t]` = action applied after `t` (leads to `state[t+1]`) — *action last* convention is common in RL/IL.

---

## 2. Target HDF5 layout (S-O-A)

Keep your current layout and add state/action groups so one file stays self-contained and backward-compatible for observation-only use.

```
recordings/trajectory.h5
├── observations/           # existing
│   ├── image              (T, H, W, 3) uint8
│   ├── depth              (T, H, W) uint16
│   └── timestamp          (T,) float64
├── state/                 # NEW
│   ├── ee_pose            (T, 6) float64  [x,y,z,rx,ry,rz] in base frame
│   ├── joint_positions    (T, J) float64  optional
│   ├── gripper_width      (T,) float64    optional
│   └── timestamp          (T,) float64    optional (for sync checks)
├── action/                # NEW
│   ├── ee_pose_delta      (T, 6) float64  or target pose, depending on convention
│   ├── gripper_command    (T,) float64    optional
│   └── timestamp          (T,) float64    optional
└── metadata/              # existing + optional
    ├── intrinsics
    ├── depth_scale, width, height
    ├── state_dim, action_dim   # optional
    └── action_type             # e.g. "delta" | "target" | "executed"
```

Use a single `T` for all time-indexed datasets so `state[t]`, `observations[t]`, and `action[t]` are aligned.

---

## 3. Implementation steps

### Phase 1: Schema and recording API

1. **Extend `realsense_wrapper.py` (or a thin wrapper)**
   - Add optional S-O-A recording mode:
     - When starting recording, accept flags like `record_state=True`, `record_action=True` and optional `state_shape`, `action_shape`.
   - After creating `observations/`, create resizable datasets under `state/` and `action/` (e.g. `state/ee_pose`, `state/timestamp`, `action/ee_pose_delta`, `action/timestamp`). Use the same `T` as observations (append one row per frame).
   - Keep observation-only recording unchanged (no `state/` or `action/` groups if not requested).

2. **Frame append contract**
   - In `get_frame()` (or a new method `get_frame_with_state_action`), after appending image/depth/timestamp, append one row to each of `state/*` and `action/*` from caller-provided arrays (see below). So: one camera frame → one state row → one action row (action at current step leading to next state).

3. **Robot interface (pluggable)**
   - Do not hardcode a specific robot. Accept a small interface, e.g.:
     - `get_state() -> np.ndarray` (e.g. concat of ee_pose, joints, gripper).
     - `get_action() -> np.ndarray` (e.g. last commanded delta or target, or leave zeros and fill offline).
   - In demos/tests, use a stub that returns zeros or a deterministic trajectory (like `calibration_traj` in `hand_eye_calibration.py`) so the pipeline runs without a real robot.

### Phase 2: Data collection script

4. **`demo_soa_record.py` (or `scripts/record_soa.py`)**
   - Parse CLI: output path, number of steps, optional robot type (“demo” vs “real”).
   - Open camera, start S-O-A recording to HDF5.
   - Loop:
     - Get robot state (from robot or demo).
     - Get camera frame (`get_frame()`).
     - Optionally get “current action” (e.g. last sent command, or zero).
     - Append observation (already done in `get_frame()` when recording), then append state and action for this step.
   - If action is “executed” (delta from state), you can either compute it online as `action[t] = state[t+1] - state[t]` after the next step, or compute offline during post-processing (see Phase 3).
   - Stop recording and close file.

5. **Synchronization**
   - Prefer one state and one action per camera frame. If robot and camera are not locked, either:
     - Trigger camera on robot tick, or
     - Record both state and observation timestamps and do alignment in post-processing (e.g. interpolate state to observation times).

### Phase 3: Reader and indexing

6. **S-O-A reader**
   - Add `HDF5SOAReader` (or extend `HDF5RecordingReader`) that:
     - Reads `observations/`, `state/`, `action/` when present.
     - Exposes `stream_soa()` yielding `(t, state, observation, action)` where `observation` is dict with `image`, `depth`, `timestamp` (and optional intrinsics from metadata).
     - Handles missing `state/` or `action/` (e.g. for observation-only files) by returning None or empty arrays.

7. **Offline action derivation (optional)**
   - If you record only state, add a small utility to compute `action[t] = state[t+1] - state[t]` (or pose delta in a consistent representation) and write it into `action/` or a separate HDF5. This keeps the main recorder simple and allows different action representations later.

### Phase 4: Docs and compatibility

8. **Documentation**
   - In README or USAGE.md: document the S-O-A layout, the convention for “action” (e.g. “action at t leads to state at t+1”), and how to plug in a real robot (`get_state` / `get_action`).
   - Add a short “Data format” section describing each dataset and its shape.

9. **Backward compatibility**
   - Existing HDF5 files (observations only) remain valid; readers should check for presence of `state` and `action` groups and skip or default when absent.

---

## 4. Suggested file changes (summary)

| File | Change |
|------|--------|
| `realsense_wrapper.py` | Optional `state/` and `action/` datasets when starting recording; extend append logic so caller can pass state/action per frame (e.g. new method or callback). |
| New: `soa_recorder.py` or in wrapper | Thin layer: `SOARecorder(RealsenseD435i, get_state, get_action)` that calls `get_frame()` and appends state/action from callbacks. |
| New: `demo_soa_record.py` | Script that uses SOARecorder with demo or real robot and writes S-O-A HDF5. |
| `realsense_wrapper.py` or new: `soa_reader.py` | `HDF5SOAReader` (or `HDF5RecordingReader` extended) with `stream_soa()`. |
| `README.md` or `USAGE.md` | S-O-A layout, convention, and how to plug robot. |

---

## 5. Design choices to fix early

- **Action convention:** Decide whether `action[t]` is (a) commanded (target/delta) or (b) executed (e.g. `state[t+1] - state[t]`), and document it. Option (b) is often easier for imitation learning when you don’t have low-level commands.
- **State representation:** Consistent units and parameterization (e.g. Euler xyz for rotation, meters for position) so training code can assume one format.
- **Real robot:** Whether state/action come from the same control cycle as the camera frame (triggered) or are timestamp-aligned later; this affects whether you need to store extra timestamps in `state/` and `action/`.

---

## 6. Minimal first milestone

To get an end-to-end S-O-A pipeline quickly:

1. Add `state/ee_pose` (T, 6) and `action/ee_pose_delta` (T, 6) to the HDF5 writer, with a simple callback or optional args to `get_frame(state=..., action=...)`.
2. Implement `demo_soa_record.py` with a **demo** state/action (e.g. from `calibration_traj` or constant zeros).
3. Implement a reader that yields `(t, state, obs_dict, action)` and verify alignment (e.g. save a short trajectory and inspect shapes and one episode in a notebook or script).

Then you can add joint positions, gripper, and real robot integration incrementally.
