#!/usr/bin/env python3
"""Demo: Record RGB-D to HDF5 (DROID SVO equivalent) and replay."""

import argparse
import os

import cv2
import numpy as np

from realsense_wrapper import RealsenseD435i, HDF5RecordingReader


def record(output_path: str, num_frames: int = 300, fps_target: int = 30):
    """Record num_frames to HDF5. ~10 sec at 30fps default."""
    print(f"Recording {num_frames} frames to {output_path}...")
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    with RealsenseD435i() as cam:
        cam.start_recording(output_path)
        for i in range(num_frames):
            frame = cam.get_frame()
            if frame is None:
                continue
            if (i + 1) % 30 == 0:
                print(f"  Recorded {i + 1}/{num_frames} frames")
        cam.stop_recording()

    print(f"Saved to {output_path}")


def replay(filepath: str):
    """Replay HDF5 recording."""
    print(f"Replaying {filepath}...")
    with HDF5RecordingReader(filepath) as reader:
        n = reader.get_frame_count()
        w, h = reader.get_frame_resolution()
        print(f"  {n} frames, {w}x{h}")

        for t, rgb, depth, ts in reader.stream():
            depth_vis = cv2.applyColorMap(
                cv2.convertScaleAbs(depth, alpha=0.03), cv2.COLORMAP_JET
            )
            combined = np.hstack((rgb, depth_vis))
            cv2.putText(
                combined,
                f"Frame {t}/{n}",
                (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 255, 0),
                2,
            )
            cv2.imshow("Replay - RGB | Depth", combined)
            if cv2.waitKey(30) & 0xFF == ord("q"):
                break

    cv2.destroyAllWindows()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--record", action="store_true", help="Record to HDF5")
    parser.add_argument("--replay", action="store_true", help="Replay from HDF5")
    parser.add_argument(
        "--path",
        default="recordings/recording.h5",
        help="HDF5 file path (default: recordings/recording.h5)",
    )
    parser.add_argument(
        "--frames",
        type=int,
        default=300,
        help="Frames to record (default: 300)",
    )
    args = parser.parse_args()

    if args.record:
        record(args.path, num_frames=args.frames)
    elif args.replay:
        replay(args.path)
    else:
        print("Use --record to record or --replay to playback.")
        print("Example: python demo_record.py --record --path recordings/demo.h5")
        print("         python demo_record.py --replay --path recordings/demo.h5")


if __name__ == "__main__":
    main()
