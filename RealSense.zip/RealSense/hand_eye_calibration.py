"""
Hand-eye calibration for RealSense D435i (DROID-style).

Supports:
- Eye-in-hand (HandCameraCalibrator): Camera on robot wrist -> camera pose in gripper frame
- Eye-to-hand (ThirdPersonCameraCalibrator): Fixed camera -> camera pose in robot base frame

Uses Charuco board + cv2.calibrateHandEye. Compatible with DROID calibration flow.
"""

from __future__ import annotations

import json
import os
import time
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np
from scipy.spatial.transform import Rotation as R

from realsense_wrapper import Intrinsics

# Charuco board params (DROID default)
CHARUCO_ROWS = 9
CHARUCO_COLS = 14
CHARUCO_SQUARE_LENGTH = 0.020  # 20mm
CHARUCO_MARKER_LENGTH = 0.016  # 16mm

# Build Charuco board (OpenCV 4.7+ vs older)
try:
    _aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_5X5_100)
except AttributeError:
    _aruco_dict = cv2.aruco.Dictionary_get(cv2.aruco.DICT_5X5_100)

try:
    CHARUCO_BOARD = cv2.aruco.CharucoBoard(
        (CHARUCO_COLS, CHARUCO_ROWS), CHARUCO_SQUARE_LENGTH, CHARUCO_MARKER_LENGTH, _aruco_dict
    )
except TypeError:
    # Older API
    CHARUCO_BOARD = cv2.aruco.CharucoBoard_create(
        CHARUCO_COLS, CHARUCO_ROWS, CHARUCO_SQUARE_LENGTH, CHARUCO_MARKER_LENGTH, _aruco_dict
    )

try:
    _detector_params = cv2.aruco.DetectorParameters()
except AttributeError:
    _detector_params = cv2.aruco.DetectorParameters_create()
_detector_params.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX

CALIB_FLAGS = (
    cv2.CALIB_USE_INTRINSIC_GUESS + cv2.CALIB_FIX_PRINCIPAL_POINT + cv2.CALIB_FIX_FOCAL_LENGTH
)


def intrinsics_to_opencv(intr: Intrinsics) -> Dict[str, np.ndarray]:
    """Convert Intrinsics to OpenCV format for aruco/calibration."""
    camera_matrix = np.array(
        [[intr.fx, 0, intr.cx], [0, intr.fy, intr.cy], [0, 0, 1]], dtype=np.float64
    )
    dist_coeffs = intr.distortion if intr.distortion is not None else np.zeros(5)
    return {"cameraMatrix": camera_matrix, "distCoeffs": dist_coeffs}


def generate_charuco_board_image(output_path: str = "charuco_board.png") -> None:
    """Generate a printable Charuco board (5x5 dict, 9x14, 20mm squares)."""
    try:
        img = CHARUCO_BOARD.generateImage((600, 400), marginSize=50, borderBits=1)
    except TypeError:
        img = CHARUCO_BOARD.generateImage((600, 400))
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    cv2.imwrite(output_path, img)
    print(f"Charuco board saved to {output_path}")


def calibration_traj(t: float, pos_scale: float = 0.1, angle_scale: float = 0.2, hand_camera: bool = False) -> np.ndarray:
    """
    Generate calibration trajectory pose. [x, y, z, rx, ry, rz] in euler xyz.

    Use to move robot through poses during calibration data collection.
    """
    x = -np.abs(np.sin(3 * t)) * pos_scale
    y = -0.8 * np.sin(2 * t) * pos_scale
    z = 0.5 * np.sin(4 * t) * pos_scale
    a = -np.sin(4 * t) * angle_scale
    b = np.sin(3 * t) * angle_scale
    c = np.sin(2 * t) * angle_scale
    if hand_camera:
        return np.array([z, y, -x, c / 1.5, b / 1.5, -a / 1.5])
    return np.array([x, y, z, a, b, c])


def load_calibration_info(filepath: str, keep_time: bool = False) -> Dict[str, Any]:
    """Load calibration from JSON. Returns {cam_id: pose or {pose, timestamp}}."""
    if not os.path.isfile(filepath):
        return {}
    with open(filepath, "r") as f:
        data = json.load(f)
    if not keep_time:
        return {k: v["pose"] if isinstance(v, dict) and "pose" in v else v for k, v in data.items()}
    return data


def save_calibration_info(filepath: str, cam_id: str, pose: List[float]) -> None:
    """Save calibration pose for a camera."""
    data: Dict[str, Any] = {}
    if os.path.isfile(filepath):
        with open(filepath, "r") as f:
            raw = json.load(f)
        for k, v in raw.items():
            if isinstance(v, dict) and "pose" in v:
                data[k] = v
            else:
                data[k] = {"pose": v, "timestamp": time.time()}
    data[cam_id] = {"pose": [float(x) for x in pose], "timestamp": time.time()}
    parent = os.path.dirname(filepath)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(filepath, "w") as f:
        json.dump(data, f, indent=2)


class CharucoDetector:
    """Detect Charuco board and compute target-to-camera transforms."""

    def __init__(
        self,
        intrinsics: Intrinsics,
        inlier_error_threshold: float = 3.0,
        reprojection_error_threshold: float = 3.0,
        num_img_threshold: int = 10,
        num_corner_threshold: int = 10,
    ):
        self.inlier_error_threshold = inlier_error_threshold
        self.reprojection_error_threshold = reprojection_error_threshold
        self.num_img_threshold = num_img_threshold
        self.num_corner_threshold = num_corner_threshold
        self._intrinsics_dict: Dict[str, Intrinsics] = {"default": intrinsics}
        self._readings_dict: Dict[str, List] = defaultdict(list)
        self._pose_dict: Dict[str, List] = defaultdict(list)
        self._curr_cam_id = "default"

    def register_camera(self, cam_id: str, intrinsics: Intrinsics) -> None:
        """Register intrinsics for a camera ID."""
        self._intrinsics_dict[cam_id] = intrinsics

    def process_image(self, image: np.ndarray) -> Optional[Tuple]:
        """Detect Charuco corners. Returns (corners, charuco_corners, charuco_ids, img_size) or None."""
        if image.shape[2] == 4:
            gray = cv2.cvtColor(image, cv2.COLOR_BGRA2GRAY)
        elif image.shape[2] == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            return None
        intr = intrinsics_to_opencv(self._intrinsics_dict[self._curr_cam_id])

        try:
            corners, ids, rejected = cv2.aruco.detectMarkers(gray, _aruco_dict, parameters=_detector_params)
        except TypeError:
            corners, ids, rejected = cv2.aruco.detectMarkers(gray, _aruco_dict, parameters=_detector_params)

        if ids is None or len(ids) == 0:
            return None

        try:
            corners, ids, _, _ = cv2.aruco.refineDetectedMarkers(
                gray, CHARUCO_BOARD, corners, ids, rejected, parameters=_detector_params, **intr
            )
        except TypeError:
            pass

        if ids is None or len(ids) == 0:
            return None

        try:
            n, charuco_corners, charuco_ids = cv2.aruco.interpolateCornersCharuco(
                corners, ids, gray, CHARUCO_BOARD, **intr
            )
        except Exception:
            return None

        if n < self.num_corner_threshold:
            return None

        return corners, charuco_corners, charuco_ids, image.shape[:2]

    def add_sample(self, cam_id: str, image: np.ndarray, gripper_pose: np.ndarray) -> bool:
        """Add (image, gripper_pose) sample. pose: [x,y,z,rx,ry,rz] euler xyz."""
        if cam_id not in self._intrinsics_dict:
            self._intrinsics_dict[cam_id] = self._intrinsics_dict["default"]
        self._curr_cam_id = cam_id
        readings = self.process_image(image)
        if readings is None:
            return False
        self._readings_dict[cam_id].append(readings)
        self._pose_dict[cam_id].append(np.asarray(gripper_pose))
        return True

    def calculate_target_to_cam(
        self, readings: List, train: bool = True
    ) -> Optional[Tuple[List[np.ndarray], List[np.ndarray], List[int]]]:
        """Return (R_target2cam_list, t_target2cam_list, success_indices) or None."""
        if len(readings) < (self.num_img_threshold if train else 5):
            return None
        init_corners = [r[1] for r in readings]
        init_ids = [r[2] for r in readings]
        img_size = readings[0][3]
        intr = intrinsics_to_opencv(self._intrinsics_dict[self._curr_cam_id])

        try:
            err, K, dist, rvecs, tvecs, _, _, per_view = cv2.aruco.calibrateCameraCharucoExtended(
                init_corners, init_ids, CHARUCO_BOARD, img_size, flags=CALIB_FLAGS, **intr
            )
        except (cv2.error, TypeError):
            err, K, dist, rvecs, tvecs = cv2.aruco.calibrateCameraCharuco(
                init_corners, init_ids, CHARUCO_BOARD, img_size, flags=CALIB_FLAGS, **intr
            )
            per_view = np.zeros(len(readings))

        inliers = [i for i, e in enumerate(per_view) if e <= self.inlier_error_threshold]
        if len(inliers) < (self.num_img_threshold if train else 5):
            return None

        final_corners = [init_corners[i] for i in inliers]
        final_ids = [init_ids[i] for i in inliers]
        err, K, dist, rvecs, tvecs = cv2.aruco.calibrateCameraCharuco(
            final_corners, final_ids, CHARUCO_BOARD, img_size, flags=CALIB_FLAGS, **intr
        )
        if err > self.reprojection_error_threshold:
            return None

        R_list = [R.from_rotvec(rv.flatten()).as_matrix() for rv in rvecs]
        t_list = [tv.flatten() for tv in tvecs]
        return R_list, t_list, inliers

    def augment_image(
        self,
        cam_id: str,
        image: np.ndarray,
        visualize: bool = False,
        visual_type: Optional[List[str]] = None,
    ) -> np.ndarray:
        """Draw markers/axes on image. visual_type: ['markers','charuco','axes']."""
        if visual_type is None:
            visual_type = ["markers", "axes"]
        self._curr_cam_id = cam_id
        if image.shape[2] == 4:
            image = cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)
        img = np.copy(image)
        readings = self.process_image(img)
        if readings is None:
            if visualize:
                cv2.imshow(f"Charuco: {cam_id}", img)
                cv2.waitKey(20)
            return img
        corners, charuco_corners, charuco_ids, img_size = readings
        intr = intrinsics_to_opencv(self._intrinsics_dict[cam_id])

        if "markers" in visual_type:
            img = cv2.aruco.drawDetectedMarkers(img, corners)
        if "charuco" in visual_type:
            img = cv2.aruco.drawDetectedCornersCharuco(img, charuco_corners, charuco_ids)
        if "axes" in visual_type:
            _, K, dist, rvecs, tvecs = cv2.aruco.calibrateCameraCharuco(
                [charuco_corners], [charuco_ids], CHARUCO_BOARD, img_size, flags=CALIB_FLAGS, **intr
            )
            cv2.drawFrameAxes(img, K, dist, rvecs[0], tvecs[0], 0.1)

        if visualize:
            cv2.imshow(f"Charuco: {cam_id}", img)
            cv2.waitKey(20)
        return img


class HandCameraCalibrator(CharucoDetector):
    """Eye-in-hand: camera on gripper. Calibrates camera pose in gripper frame."""

    def __init__(self, intrinsics: Intrinsics, **kwargs: Any):
        super().__init__(intrinsics, **kwargs)

    def calibrate(self, cam_id: str = "default") -> Optional[np.ndarray]:
        """
        Compute camera-to-gripper transform. Returns [x,y,z,rx,ry,rz] or None.
        gripper_pose: end-effector pose in robot base frame [x,y,z,rx,ry,rz].
        """
        self._curr_cam_id = cam_id
        readings = self._readings_dict.get(cam_id, [])
        gripper_poses = self._pose_dict.get(cam_id, [])
        if len(readings) < self.num_img_threshold:
            return None

        result = self.calculate_target_to_cam(readings)
        if result is None:
            return None
        R_target2cam, t_target2cam, successes = result
        gripper_poses = np.array(gripper_poses)[successes]

        R_gripper2base = [R.from_euler("xyz", p[3:6]).as_matrix() for p in gripper_poses]
        t_gripper2base = [np.array(p[:3]) for p in gripper_poses]

        # DROID uses method 4 (Daniilidis)
        method = getattr(cv2, "CALIB_HAND_EYE_DANIILIDIS", 4)
        rmat, tvec = cv2.calibrateHandEye(
            R_gripper2base=R_gripper2base,
            t_gripper2base=t_gripper2base,
            R_target2cam=R_target2cam,
            t_target2cam=t_target2cam,
            method=method,
        )
        pos = tvec.flatten()
        eul = R.from_matrix(rmat).as_euler("xyz")
        return np.concatenate([pos, eul])


class ThirdPersonCameraCalibrator(CharucoDetector):
    """Eye-to-hand: fixed camera. Calibrates camera pose in robot base frame."""

    def __init__(self, intrinsics: Intrinsics, **kwargs: Any):
        super().__init__(intrinsics, **kwargs)

    def calibrate(self, cam_id: str = "default") -> Optional[np.ndarray]:
        """
        Compute camera-to-base transform. Returns [x,y,z,rx,ry,rz] or None.
        gripper_pose: end-effector pose in base frame [x,y,z,rx,ry,rz].
        Target board is held by gripper (or fixed; gripper moves relative to board).
        """
        self._curr_cam_id = cam_id
        readings = self._readings_dict.get(cam_id, [])
        gripper_poses = self._pose_dict.get(cam_id, [])
        if len(readings) < self.num_img_threshold:
            return None

        result = self.calculate_target_to_cam(readings)
        if result is None:
            return None
        R_target2cam, t_target2cam, successes = result
        gripper_poses = np.array(gripper_poses)[successes]

        # Base to gripper (inverse of gripper pose in base)
        R_base2gripper = [R.from_euler("xyz", p[3:6]).inv().as_matrix() for p in gripper_poses]
        t_base2gripper = [-Rbg @ np.array(p[:3]) for Rbg, p in zip(R_base2gripper, gripper_poses)]

        method = getattr(cv2, "CALIB_HAND_EYE_DANIILIDIS", 4)
        rmat, tvec = cv2.calibrateHandEye(
            R_gripper2base=R_base2gripper,
            t_gripper2base=t_base2gripper,
            R_target2cam=R_target2cam,
            t_target2cam=t_target2cam,
            method=method,
        )
        pos = tvec.flatten()
        eul = R.from_matrix(rmat).as_euler("xyz")
        return np.concatenate([pos, eul])
