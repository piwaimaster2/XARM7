"""
Robot-agnostic velocity/delta scaling for DROID action spaces.
No MJCF, no dm_control; used by XARM7 (and any robot that does not use RobotIKSolver).
Franka continues to use RobotIKSolver which has the same scaling constants plus IK.
"""

import numpy as np


class VelocityScaling:
    """Pure velocity <-> delta scaling with configurable limits. No robot model."""

    def __init__(
        self,
        max_lin_delta=0.075,
        max_rot_delta=0.15,
        max_gripper_delta=0.25,
        relative_max_joint_delta=None,
        control_hz=15,
    ):
        if relative_max_joint_delta is None:
            relative_max_joint_delta = np.array([0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2])
        self.relative_max_joint_delta = np.asarray(relative_max_joint_delta, dtype=float)
        self.max_joint_delta = float(self.relative_max_joint_delta.max())
        self.max_gripper_delta = float(max_gripper_delta)
        self.max_lin_delta = float(max_lin_delta)
        self.max_rot_delta = float(max_rot_delta)
        self.control_hz = int(control_hz)

    # --- Velocity -> Delta ---
    def gripper_velocity_to_delta(self, gripper_velocity, dt=None):
        
        gripper_vel_norm = np.linalg.norm(gripper_velocity)
        if gripper_vel_norm > 1:
            gripper_velocity = gripper_velocity / gripper_vel_norm
        out = gripper_velocity * self.max_gripper_delta
        if dt is not None:
            out = out * dt * self.control_hz
        return out

    def cartesian_velocity_to_delta(self, cartesian_velocity, dt=None):
        
        if isinstance(cartesian_velocity, list):
            cartesian_velocity = np.array(cartesian_velocity)
        lin_vel, rot_vel = cartesian_velocity[:3], cartesian_velocity[3:6]
        lin_vel_norm = np.linalg.norm(lin_vel)
        rot_vel_norm = np.linalg.norm(rot_vel)
        if lin_vel_norm > 1:
            lin_vel = lin_vel / lin_vel_norm
        if rot_vel_norm > 1:
            rot_vel = rot_vel / rot_vel_norm
        lin_delta = lin_vel * self.max_lin_delta
        rot_delta = rot_vel * self.max_rot_delta
        out = np.concatenate([lin_delta, rot_delta])
        if dt is not None:
            out = out * dt * self.control_hz
        return out

    def joint_velocity_to_delta(self, joint_velocity, dt=None):
        
        if isinstance(joint_velocity, list):
            joint_velocity = np.array(joint_velocity)
        relative_max_joint_vel = self.joint_delta_to_velocity(self.relative_max_joint_delta)
        max_joint_vel_norm = (np.abs(joint_velocity) / relative_max_joint_vel).max()
        if max_joint_vel_norm > 1:
            joint_velocity = joint_velocity / max_joint_vel_norm
        out = joint_velocity * self.max_joint_delta
        if dt is not None:
            out = out * dt * self.control_hz
        return out

    # --- Delta -> Velocity ---
    def gripper_delta_to_velocity(self, gripper_delta):
        return gripper_delta / self.max_gripper_delta

    def cartesian_delta_to_velocity(self, cartesian_delta):
        if isinstance(cartesian_delta, list):
            cartesian_delta = np.array(cartesian_delta)
        cartesian_velocity = np.zeros_like(cartesian_delta)
        cartesian_velocity[:3] = cartesian_delta[:3] / self.max_lin_delta
        cartesian_velocity[3:6] = cartesian_delta[3:6] / self.max_rot_delta
        return cartesian_velocity

    def joint_delta_to_velocity(self, joint_delta):
        if isinstance(joint_delta, list):
            joint_delta = np.array(joint_delta)
        return joint_delta / self.max_joint_delta
