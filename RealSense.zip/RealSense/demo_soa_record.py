#!/usr/bin/env python3
"""Demo: Record State-Observation-Action (S-O-A) sequences to LeRobot Dataset.

Records episodic data with RGB images (no depth), observation.state, and action.
Press 'e' to end current episode and start a new one. Press Ctrl+C to stop recording.
"""

from __future__ import annotations

import argparse
import os
import time
from pathlib import Path
from typing import Callable, Optional

import cv2
import numpy as np

try:
    from lerobot.datasets.lerobot_dataset import LeRobotDataset
    from lerobot.utils.constants import ACTION, OBS_IMAGES, OBS_STATE
except ImportError as e:
    raise ImportError(
        "lerobot is required. Activate the XARM7 conda env: conda activate XARM7"
    ) from e

from hand_eye_calibration import calibration_traj
from realsense_wrapper import RealsenseD435i

# Robot adapter: callable that returns current state [x,y,z,rx,ry,rz]
RobotGetState = Callable[[], np.ndarray]
# Per-step factory: (step_index) -> RobotGetState (for DROID trajectory)
GetStateFactory = Callable[[int], RobotGetState]
# Joint angles: callable that returns [7] joint angles in radians
RobotGetJointAngles = Callable[[], np.ndarray]
# Gripper: callable that returns [1] gripper position (e.g. 0=closed, larger=open)
RobotGetGripper = Callable[[], np.ndarray]

FPS = 30
CAMERA_KEY = "top"


def get_state_demo(step: int, total_steps: int) -> np.ndarray:
    """Demo: synthesize EE pose from trajectory."""
    t = step / max(total_steps - 1, 1) * 2.0 * np.pi
    return calibration_traj(t, pos_scale=0.1, angle_scale=0.2, hand_camera=False)


def get_joint_angles_demo(step: int, total_steps: int) -> np.ndarray:
    """Demo: synthesize 7 joint angles (radians). Sinusoidal pattern."""
    t = step / max(total_steps - 1, 1) * 2.0 * np.pi
    return np.array(
        [np.sin(t + i * 0.5) * 0.3 for i in range(7)],
        dtype=np.float64,
    )


def get_gripper_demo(step: int, total_steps: int) -> np.ndarray:
    """Demo: synthesize gripper position in [0, 1] (0=closed, 1=open)."""
    t = step / max(total_steps - 1, 1) * 2.0 * np.pi
    return np.array([0.5 + 0.5 * np.sin(t)], dtype=np.float64)


def _make_lerobot_features(
    height: int, width: int, has_joint_angles: bool, has_gripper: bool = False
) -> dict:
    """Build LeRobot dataset features: RGB camera + observation.state + action (+ optional gripper)."""
    # ee_pose (6) + optional joints (7) + optional gripper (1)
    state_dim = 6
    names = ["ee_x", "ee_y", "ee_z", "ee_rx", "ee_ry", "ee_rz"]
    if has_joint_angles:
        state_dim += 7
        names += ["j0", "j1", "j2", "j3", "j4", "j5", "j6"]
    if has_gripper:
        state_dim += 1
        names += ["gripper"]
    return {
        f"{OBS_IMAGES}.{CAMERA_KEY}": {
            "dtype": "video",
            "shape": (height, width, 3),
            "names": ["height", "width", "channels"],
        },
        OBS_STATE: {
            "dtype": "float32",
            "shape": (state_dim,),
            "names": names,
        },
        ACTION: {
            "dtype": "float32",
            "shape": (state_dim,),
            "names": [n + "_delta" for n in names],
        },
    }


def record_soa(
    output_path: str,
    task: str = "Manipulation task",
    get_state: Optional[RobotGetState] = None,
    get_state_factory: Optional[GetStateFactory] = None,
    get_joint_angles: Optional[RobotGetJointAngles] = None,
    get_joint_angles_factory: Optional[Callable[[int], RobotGetJointAngles]] = None,
    get_gripper: Optional[RobotGetGripper] = None,
    get_gripper_factory: Optional[Callable[[int], RobotGetGripper]] = None,
) -> None:
    """
    Record S-O-A episodes to LeRobot Dataset.

    Press 'e' to end current episode and start a new one.
    Press Ctrl+C to stop recording.
    """
    def _make_get_state(step: int, total: int) -> RobotGetState:
        return lambda: get_state_demo(step, total)

    traj_total = 10000  # for demo trajectory scaling
    if get_state_factory is not None:
        get_state_factory_final = get_state_factory
    elif get_state is not None:
        get_state_factory_final = lambda step: get_state
    else:
        get_state_factory_final = lambda step: _make_get_state(step, traj_total)

    has_joint_angles = get_joint_angles is not None or get_joint_angles_factory is not None
    if get_joint_angles_factory is not None:
        get_joint_angles_factory_final = get_joint_angles_factory
    elif get_joint_angles is not None:
        get_joint_angles_factory_final = lambda step: get_joint_angles
    else:
        get_joint_angles_factory_final = None

    has_gripper = get_gripper is not None or get_gripper_factory is not None
    if get_gripper_factory is not None:
        get_gripper_factory_final = get_gripper_factory
    elif get_gripper is not None:
        get_gripper_factory_final = lambda step: get_gripper
    else:
        get_gripper_factory_final = None

    output_dir = Path(output_path).resolve()
    if output_dir.exists():
        raise FileExistsError(
            f"Dataset path already exists: {output_dir}\n"
            "LeRobot requires a fresh directory. Use a new path or remove the existing one."
        )
    repo_id = output_dir.name
    root = output_dir

    print(f"Recording to {root} (LeRobot Dataset)")
    print(f"  Task: {task}")
    print(f"  Press 'e' to end episode (with display), Ctrl+C to stop recording.")
    if has_joint_angles:
        print("  Recording 7 joint angles.")
    if has_gripper:
        print("  Recording gripper status.")

    # Detect headless (no display / OpenCV built without GUI)
    use_gui = True
    try:
        cv2.namedWindow("Recording", cv2.WINDOW_NORMAL)
        cv2.destroyWindow("Recording")
    except cv2.error:
        use_gui = False
        print("  Headless mode: no preview. Press Ctrl+C when done to stop and save.")

    with RealsenseD435i() as cam:
        H, W = cam.height, cam.width
        features = _make_lerobot_features(H, W, has_joint_angles, has_gripper=has_gripper)

        dataset = LeRobotDataset.create(
            repo_id=repo_id,
            fps=FPS,
            features=features,
            root=root,
            robot_type="xarm7",
            use_videos=True,
            vcodec="h264",  # h264 is widely supported; libsvtav1 may need extra deps
        )

        prev_state = None
        prev_joint_state = None
        step_index = 0
        episode_count = 0
        frame_count = 0
        current_episode_frames = 0

        try:
            while True:
                frame_obj = cam.get_frame()
                if frame_obj is None:
                    continue

                step_get_state = get_state_factory_final(step_index)
                step_get_joint = get_joint_angles_factory_final(step_index) if has_joint_angles else None
                step_get_gripper = get_gripper_factory_final(step_index) if has_gripper else None

                # State
                state = np.asarray(step_get_state(), dtype=np.float32)
                state = state[:6] if state.size >= 6 else np.resize(state, 6)

                if has_joint_angles:
                    joint_state = np.asarray(step_get_joint(), dtype=np.float32)
                    joint_state = joint_state[:7] if joint_state.size >= 7 else np.resize(joint_state, 7)
                    state_vec = np.concatenate([state, joint_state]).astype(np.float32)
                else:
                    state_vec = state.astype(np.float32)

                if has_gripper:
                    gripper_state = np.asarray(step_get_gripper(), dtype=np.float32)
                    gripper_state = gripper_state[:1] if gripper_state.size >= 1 else np.array([0.0], dtype=np.float32)
                    state_vec = np.concatenate([state_vec, gripper_state]).astype(np.float32)

                # Action (delta from prev)
                if prev_state is not None:
                    action_vec = state_vec - prev_state
                else:
                    action_vec = np.zeros_like(state_vec)

                prev_state = state_vec.copy()

                # Build LeRobot frame (timestamp is auto-computed by add_frame)
                lr_frame = {
                    f"{OBS_IMAGES}.{CAMERA_KEY}": frame_obj.rgb,
                    OBS_STATE: state_vec,
                    ACTION: action_vec,
                    "task": task,
                }

                dataset.add_frame(lr_frame)

                current_episode_frames += 1
                frame_count += 1
                step_index += 1

                # Live preview and key handling (skip when headless)
                if use_gui:
                    if frame_count % 10 == 0:
                        disp = frame_obj.rgb.copy()
                        label = f"Ep {episode_count} | Frame {current_episode_frames} | Total {frame_count}"
                        cv2.putText(disp, label, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                        cv2.putText(disp, "Press 'e'=new episode, Ctrl+C=stop", (10, 55), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
                        cv2.imshow("Recording", disp)

                    key = cv2.waitKey(1) & 0xFF
                    if key == ord("e"):
                        if current_episode_frames > 0:
                            dataset.save_episode()
                            episode_count += 1
                            print(f"  Episode {episode_count} saved ({current_episode_frames} frames)")
                        current_episode_frames = 0
                        prev_state = None
                    elif key == ord("q"):
                        break
                else:
                    time.sleep(1.0 / FPS)  # maintain frame rate when headless

        except KeyboardInterrupt:
            pass

        # Save final episode if any frames (Ctrl+C stops recording)
        if current_episode_frames > 0:
            try:
                dataset.save_episode()
                episode_count += 1
                print(f"  Episode {episode_count} saved ({current_episode_frames} frames)")
            except Exception as e:
                print(f"  Warning: could not save final episode: {e}")
                print("  (Data from this episode may be partial; previous episodes are intact.)")

        if use_gui:
            cv2.destroyAllWindows()
        dataset.finalize()
        print(f"Saved {episode_count} episodes, {frame_count} frames to {root}")


def replay_soa(
    repo_id_or_path: str,
    root: Optional[str] = None,
    video_backend: Optional[str] = None,
    output: Optional[str] = None,
) -> None:
    """Replay a LeRobot Dataset recording.

    video_backend: None = use LeRobot default (torchcodec if FFmpeg available, else pyav).
    output: When set, save replay to MP4 file (for headless systems without display).
    """
    print(f"Replaying {repo_id_or_path}...")
    # Default to pyav; torchcodec needs FFmpeg libs (conda install -c conda-forge ffmpeg)
    video_backend = video_backend if video_backend is not None else "pyav"
    kw = {"video_backend": video_backend}

    def _make_dataset():
        if root is not None:
            return LeRobotDataset(repo_id_or_path, root=Path(root), **kw)
        p = Path(repo_id_or_path).resolve()
        if p.exists() and (p / "meta" / "info.json").exists():
            return LeRobotDataset(p.name, root=p, **kw)
        return LeRobotDataset(repo_id_or_path, **kw)

    dataset = _make_dataset()
    n = len(dataset)
    print(f"  {n} frames, {dataset.meta.total_episodes} episodes")

    # Detect if we can show a window (OpenCV needs GUI support)
    use_display = output is None
    if use_display:
        try:
            cv2.namedWindow("LeRobot Replay", cv2.WINDOW_NORMAL)
            cv2.destroyWindow("LeRobot Replay")
        except cv2.error:
            use_display = False
            output = output or str(Path(repo_id_or_path).name) + "_replay.mp4"
            print(f"  No display available. Saving to {output}")

    writer = None
    if output is not None:
        output = Path(output).resolve()
        output.parent.mkdir(parents=True, exist_ok=True)

    def _replay_loop(ds):
        nonlocal writer
        for i in range(n):
            sample = ds[i]
            img_key = f"{OBS_IMAGES}.{CAMERA_KEY}"
            if img_key in sample:
                rgb = sample[img_key]
                if hasattr(rgb, "numpy"):
                    rgb = rgb.numpy()
                if rgb.ndim == 3 and rgb.shape[0] == 3:
                    rgb = np.transpose(rgb, (1, 2, 0))
                rgb = np.ascontiguousarray(np.asarray(rgb, dtype=np.uint8))
            else:
                continue

            label = f"Frame {i}/{n}"
            if OBS_STATE in sample:
                state = sample[OBS_STATE]
                if hasattr(state, "numpy"):
                    state = state.numpy()
                label += f"  state=[{','.join(f'{s:.2f}' for s in state[:6])}]"
                if len(state) > 6:
                    joint_slice = state[6:13] if len(state) >= 13 else state[6:]
                    label += f"  joints=[{','.join(f'{j:.2f}' for j in joint_slice)}]"
                if len(state) > 13:
                    label += f"  grip={state[13]:.2f}"

            cv2.putText(rgb, label, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

            if output is not None:
                if writer is None:
                    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
                    h, w = rgb.shape[:2]
                    writer = cv2.VideoWriter(str(output), fourcc, FPS, (w, h))
                writer.write(rgb)
            if use_display:
                cv2.imshow("LeRobot Replay", rgb)
                if cv2.waitKey(30) & 0xFF == ord("q"):
                    break

    try:
        _replay_loop(dataset)
    except RuntimeError as e:
        if video_backend == "torchcodec" and ("libtorchcodec" in str(e) or "Could not load" in str(e)):
            print("  TorchCodec failed (FFmpeg not found). Falling back to pyav...")
            kw["video_backend"] = "pyav"
            dataset = _make_dataset()
            _replay_loop(dataset)
        else:
            raise

    if writer is not None:
        writer.release()
        print(f"  Saved replay to {output}")
    if use_display:
        cv2.destroyAllWindows()

def _load_trajectory(path: str) -> np.ndarray:
    """Load trajectory from .npy or .npz. Expects (T, 6) or (T, 7)."""
    path = os.path.abspath(path)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Trajectory file not found: {path}")
    if path.endswith(".npz"):
        data = np.load(path)
        key = "poses" if "poses" in data else "trajectory" if "trajectory" in data else list(data.keys())[0]
        return np.array(data[key])
    return np.load(path)


def main():
    parser = argparse.ArgumentParser(
        description="Record or replay State-Observation-Action (S-O-A) LeRobot Dataset sequences."
    )
    parser.add_argument("--record", action="store_true", help="Record to LeRobot Dataset")
    parser.add_argument("--replay", action="store_true", help="Replay from LeRobot Dataset")
    parser.add_argument(
        "--path",
        default="recordings/soa_demo",
        help="Dataset path (directory for LeRobot format). Default: recordings/soa_demo",
    )
    parser.add_argument(
        "--task",
        default="Manipulation task",
        help="Task description for recorded episodes",
    )
    parser.add_argument(
        "--robot",
        choices=["demo", "xarm7", "droid"],
        default="demo",
        help="State source: demo (synthetic), xarm7 (real robot), droid (DROID-SLAM trajectory)",
    )
    parser.add_argument(
        "--xarm-port",
        default="192.168.1.215",
        help="xArm7 IP (default: 192.168.1.215). Requires pip install xArm-Python-SDK",
    )
    parser.add_argument(
        "--droid-trajectory",
        default=None,
        help="Path to DROID-SLAM trajectory .npy or .npz (T,6) or (T,7). Required for --robot droid",
    )
    parser.add_argument(
        "--video-backend",
        choices=["pyav", "torchcodec"],
        default=None,
        help="Video decoder for replay: pyav (fallback) or torchcodec (needs FFmpeg). Default: auto.",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Replay: save to MP4 file instead of display (use when headless / no GUI).",
    )
    args = parser.parse_args()

    if args.record:
        get_state = None
        get_state_factory = None

        if args.robot == "xarm7":
            from robot_adapters import (
                get_state_from_xarm7,
                get_joint_angles_from_xarm7,
                get_gripper_from_xarm7,
            )
            arm, get_state = get_state_from_xarm7(port=args.xarm_port)
            get_joint_angles = get_joint_angles_from_xarm7(arm)
            get_gripper = get_gripper_from_xarm7(arm)
            try:
                record_soa(
                    args.path,
                    task=args.task,
                    get_state=get_state,
                    get_joint_angles=get_joint_angles,
                    get_gripper=get_gripper,
                )
            finally:
                arm.disconnect()

        elif args.robot == "droid":
            if not args.droid_trajectory:
                parser.error("--robot droid requires --droid-trajectory PATH")
            traj = _load_trajectory(args.droid_trajectory)
            from robot_adapters import make_droid_get_state_factory
            get_state_factory = make_droid_get_state_factory(traj)
            record_soa(
                args.path,
                task=args.task,
                get_state_factory=get_state_factory,
            )

        else:
            traj_total = 10000
            record_soa(
                args.path,
                task=args.task,
                get_joint_angles_factory=lambda step: lambda: get_joint_angles_demo(step, traj_total),
                get_gripper_factory=lambda step: lambda: get_gripper_demo(step, traj_total),
            )
    elif args.replay:
        replay_soa(args.path, video_backend=args.video_backend, output=args.output)
    else:
        print("Use --record to record or --replay to playback.")
        print("Examples:")
        print("  python demo_soa_record.py --record --path recordings/soa_demo --task 'Pick cube'")
        print("  python demo_soa_record.py --record --robot xarm7 --xarm-port 192.168.1.215")
        print("  python demo_soa_record.py --replay --path recordings/soa_demo")
        print("  python demo_soa_record.py --replay --path recordings/soa_demo --output replay.mp4  # headless")


if __name__ == "__main__":
    main()
